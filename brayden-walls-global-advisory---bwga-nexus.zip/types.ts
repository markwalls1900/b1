export interface ScoringDimension {
  id: string;
  name: string;
  description: string;
  weight: number;
}

export interface InvestmentParams {
  organization: string;
  country: string;
  industry: string;
  objective: string;
  dealbreaker: string;
}

export enum InvestmentTier {
  Premium = "Tier 1 - Premium Investment",
  Strategic = "Tier 2 - Strategic Investment",
  Emerging = "Tier 3 - Emerging Opportunity",
}

export interface PartnerMatch {
  name: string;
  type: string;
  expertise: string;
  focus: 'business' | 'government' | 'both';
}

export interface AnalysisResult {
  params: InvestmentParams;
  rawScore: number;
  finalScore: number;
  tier: InvestmentTier;
  tierDescription: string;
  narrative: string;
  keyDrivers: string[];
  keyRisks: string[];
  partnerMatches: PartnerMatch[];
}

export type UserType = 'business' | 'government';

export interface QuestionnaireQuestion {
  id: keyof Omit<InvestmentParams, 'dimensionScores' | 'dimensionScores'>;
  label: string;
  type: 'text' | 'select';
  placeholder?: string;
  options?: string[];
}

export interface ReportTier {
    id: string;
    name: string;
    price: string;
    description: string;
    features: string[];
    recommendation?: string;
}

export interface TrendMetric {
    value: string | number;
    trend: 'up' | 'down' | 'stable';
    description: string;
}

export interface RegionalData {
    id: string;
    name: string;
    country: string;
    countryCode: string; 
    opportunityScore: number;
    riskFactor: string;
    briefing?: string;
    
    kpis: {
        gdpGrowth: TrendMetric;
        fdiInflow: TrendMetric;
        unemploymentRate: TrendMetric;
        easeOfBusiness: TrendMetric;
        corruptionPerception: TrendMetric;
        internetSpeed: TrendMetric;
    }
}
