import React, { useState, useCallback, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { type UserType, type InvestmentParams, type RegionalData } from './types';
import { generateDashboardBriefing } from './services/geminiService';
import Dashboard from './components/Dashboard';
import Questionnaire from './components/Questionnaire';
import LoadingScreen from './components/LoadingScreen';
import { REGIONAL_DATA } from './constants';

export type AppStep = 'dashboard' | 'questionnaire' | 'loading' | 'result';

function App() {
  const [step, setStep] = useState<AppStep>('dashboard');
  const [userType, setUserType] = useState<UserType | null>(null);
  const [selectedRegionId, setSelectedRegionId] = useState<string>('philippines');
  const [regionalData, setRegionalData] = useState<Record<string, RegionalData>>(REGIONAL_DATA);
  const [isBriefingLoading, setIsBriefingLoading] = useState<boolean>(true);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);

  const handleSelectRegion = useCallback((id: string) => {
    if (id !== selectedRegionId) {
      setSelectedRegionId(id);
    }
  }, [selectedRegionId]);

  useEffect(() => {
    const fetchBriefing = async () => {
      setIsBriefingLoading(true);
      const currentRegionData = regionalData[selectedRegionId];
      // Ensure we don't refetch if briefing already exists.
      if (currentRegionData && !currentRegionData.briefing) { 
        const briefing = await generateDashboardBriefing(currentRegionData);
        setRegionalData(prevData => ({
          ...prevData,
          [selectedRegionId]: { ...prevData[selectedRegionId], briefing }
        }));
      }
      setIsBriefingLoading(false);
    };
    fetchBriefing();
  }, [selectedRegionId, regionalData]);


  const handleStartGeneration = (type: UserType) => {
    setUserType(type);
    setStep('questionnaire');
  };

  const handleQuestionnaireSubmit = (data: Omit<InvestmentParams, 'dimensionScores'>) => {
    console.log("Questionnaire submitted, proceeding to loading:", data);
    setStep('loading');
    // Simulate analysis time before showing an alert and returning to the dashboard.
    // In a real app, this would lead to a results/payment page.
    setTimeout(() => {
        alert("Full Report Generation is a premium service. This demonstration illustrates the data collection and analysis flow. Returning to the dashboard.");
        setStep('dashboard');
        setUserType(null); // Reset user type
    }, 2000);
  };
  
  const handleBackToDashboard = () => {
    setUserType(null);
    setStep('dashboard');
  };
  
  const renderContent = () => {
      switch (step) {
          case 'questionnaire':
              return <Questionnaire userType={userType!} onSubmit={handleQuestionnaireSubmit} onBack={handleBackToDashboard} />;
          case 'loading':
              return <LoadingScreen />;
          case 'dashboard':
          default:
             return (
                <Dashboard 
                    regionalData={regionalData}
                    selectedRegionId={selectedRegionId} 
                    onSelectRegion={handleSelectRegion} 
                    onStartGeneration={handleStartGeneration}
                    isBriefingLoading={isBriefingLoading}
                    onShowMethodology={() => setIsMethodologyOpen(true)}
                />
              );
      }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 antialiased">
        <main className="w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>
         {isMethodologyOpen && (
             <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                <motion.div
                 initial={{ opacity: 0, scale: 0.95 }}
                 animate={{ opacity: 1, scale: 1 }}
                 exit={{ opacity: 0, scale: 0.95 }}
                 className="bg-white max-w-2xl w-full p-8 rounded-xl shadow-2xl border border-slate-200">
                    <h2 className="text-2xl font-bold text-slate-900 mb-4">Our Methodology</h2>
                    <div className="prose prose-sm max-w-none text-slate-600">
                        <p>The BWGA Nexus dashboard synthesizes data from multiple public and proprietary sources to generate a holistic <strong>Opportunity Score</strong>.</p>
                        <p>Our AI, <strong>NSIL™</strong>, analyzes metrics across key domains:</p>
                        <ul>
                            <li><strong>Economic Outlook:</strong> Based on GDP growth and FDI inflows.</li>
                            <li><strong>Governance:</strong> Reflects ease of doing business and corruption perception.</li>
                            <li><strong>Human Capital:</strong> Derived from unemployment rates and other demographic data.</li>
                        </ul>
                        <p>The <strong>Executive Briefing</strong> is an AI-generated narrative that provides a C-suite level summary, connecting these data points to provide strategic, actionable insights.</p>
                    </div>
                    <button onClick={() => setIsMethodologyOpen(false)} className="mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg transition-colors">
                        Close
                    </button>
                </motion.div>
            </div>
        )}
    </div>
  );
}

export default App;
