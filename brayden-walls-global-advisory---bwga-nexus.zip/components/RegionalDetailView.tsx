import React from 'react';
import { RegionalData } from '../types';
import ExecutiveBriefingView from './ExecutiveBriefingView';
import KPICard from './KPICard';
import { GlobeAltIcon, ChartBarIcon, ScaleIcon, UserGroupIcon, ShieldCheckIcon, WifiIcon } from './Icons';


const RegionalDetailView: React.FC<{ region: RegionalData; briefing: string | undefined; isLoading: boolean }> = ({ region, briefing, isLoading }) => {
    
    return (
        <div className="space-y-8">
            <ExecutiveBriefingView region={region} briefing={briefing} isLoading={isLoading} />
            
            <div>
                <h3 className="text-xl font-bold text-slate-800 mb-4">Key Performance Indicators</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    <KPICard 
                        icon={<ChartBarIcon />}
                        title="Economic Outlook"
                        metric={region.kpis.gdpGrowth.value}
                        trend={region.kpis.gdpGrowth.trend}
                        description={region.kpis.gdpGrowth.description}
                    />
                    <KPICard 
                        icon={<GlobeAltIcon />}
                        title="FDI Inflow (YoY)"
                        metric={region.kpis.fdiInflow.value}
                        trend={region.kpis.fdiInflow.trend}
                        description={region.kpis.fdiInflow.description}
                    />
                    <KPICard 
                        icon={<UserGroupIcon />}
                        title="Unemployment Rate"
                        metric={region.kpis.unemploymentRate.value}
                        trend={region.kpis.unemploymentRate.trend}
                        description={region.kpis.unemploymentRate.description}
                        positiveTrend='down'
                    />
                    <KPICard 
                        icon={<ScaleIcon />}
                        title="Ease of Business"
                        metric={`${region.kpis.easeOfBusiness.value}/100`}
                        trend={region.kpis.easeOfBusiness.trend}
                        description={region.kpis.easeOfBusiness.description}
                    />
                    <KPICard 
                        icon={<ShieldCheckIcon />}
                        title="Corruption Index"
                        metric={`${region.kpis.corruptionPerception.value}/100`}
                        trend={region.kpis.corruptionPerception.trend}
                        description={region.kpis.corruptionPerception.description}
                    />
                    <KPICard 
                        icon={<WifiIcon />}
                        title="Internet Speed"
                        metric={region.kpis.internetSpeed.value}
                        trend={region.kpis.internetSpeed.trend}
                        description={region.kpis.internetSpeed.description}
                    />
                </div>
            </div>
        </div>
    );
};

export default RegionalDetailView;
