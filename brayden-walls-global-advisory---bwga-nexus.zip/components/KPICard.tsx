import React from 'react';
import { ArrowUpIcon, ArrowDownIcon, MinusIcon } from './Icons';

interface KPICardProps {
    icon: React.ReactNode;
    title: string;
    metric: string | number;
    trend: 'up' | 'down' | 'stable';
    description: string;
    positiveTrend?: 'up' | 'down';
}

const TrendIndicator: React.FC<{ trend: 'up' | 'down' | 'stable', positiveTrend: 'up' | 'down' }> = ({ trend, positiveTrend }) => {
    const isPositive = trend === positiveTrend;
    const isNegative = (trend === 'up' && positiveTrend === 'down') || (trend === 'down' && positiveTrend === 'up');

    if (trend === 'up') return <ArrowUpIcon className={`w-5 h-5 ${isPositive ? 'text-green-500' : 'text-red-500'}`} />;
    if (trend === 'down') return <ArrowDownIcon className={`w-5 h-5 ${isPositive ? 'text-green-500' : 'text-red-500'}`} />;
    return <MinusIcon className="w-5 h-5 text-slate-500" />;
};

const KPICard: React.FC<KPICardProps> = ({ icon, title, metric, trend, description, positiveTrend = 'up' }) => {
    return (
        <div className="bg-white p-5 rounded-lg shadow-sm border border-slate-200 flex flex-col justify-between hover:border-blue-500 hover:shadow-md transition-all duration-300 group">
            <div>
                <div className="flex items-center text-slate-500 group-hover:text-blue-600 transition-colors duration-300 mb-3">
                    <span className="w-6 h-6 mr-2">{icon}</span>
                    <h3 className="font-semibold text-sm uppercase tracking-wider">{title}</h3>
                </div>
                <div className="flex items-baseline space-x-2">
                    <p className="text-3xl font-bold text-slate-900">{metric}</p>
                    <div title={`Trend: ${trend}`}>
                       <TrendIndicator trend={trend} positiveTrend={positiveTrend} />
                    </div>
                </div>
            </div>
            <p className="text-xs text-slate-500 mt-3">{description}</p>
        </div>
    );
};

export default KPICard;
