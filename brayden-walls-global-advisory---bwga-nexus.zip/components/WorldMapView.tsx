import React from 'react';
import type { RegionalData } from '../types';

interface WorldMapViewProps {
  selectedRegionId: string;
  onSelectRegion: (id: string) => void;
  regionalData: Record<string, RegionalData>;
}

// Simplified SVG paths for a more recognizable world map layout
const COUNTRY_PATHS: Record<string, string> = {
  // Asia-Pacific backdrop
  asia: "M600,100 L850,80 L800,300 L620,280 Z",
  australia: "M780,400 L900,420 L850,500 L750,480 Z",
  // Specific SEA countries as interactive hotspots, scaled down for sidebar
  philippines: "M810,255 a 15 15 0 0 1 0 30 a 15 15 0 0 1 0 -30",
  vietnam: "M765,265 a 12 12 0 0 1 0 24 a 12 12 0 0 1 0 -24",
  indonesia: "M790,320 a 18 18 0 0 1 0 36 a 18 18 0 0 1 0 -36",
  malaysia: "M740,305 a 10 10 0 0 1 0 20 a 10 10 0 0 1 0 -20",
};

const CountryShape: React.FC<{
  pathData: { id: string; path: string; isInteractive: boolean };
  selected: boolean;
  onSelect: () => void;
  score: number;
  countryName: string;
}> = ({ pathData, selected, onSelect, score, countryName }) => {
  const intensity = Math.max(0, (score - 65) / 35); // Normalize score from 65-100 to 0-1
  const color = `rgba(59, 130, 246, ${0.15 + intensity * 0.8})`; // blue-500 with varying opacity

  return (
    <path
      d={pathData.path}
      onClick={pathData.isInteractive ? onSelect : undefined}
      className={`${pathData.isInteractive ? 'cursor-pointer hover:stroke-blue-500' : 'pointer-events-none'} transition-all duration-200 ease-in-out`}
      fill={selected ? "#2563eb" : (pathData.isInteractive ? color : '#e5e7eb')}
      stroke={selected ? "#1e40af" : (pathData.isInteractive ? "#60a5fa" : "#d1d5db")}
      strokeWidth={selected ? "2" : (pathData.isInteractive ? "1" : "0.5")}
    >
      {pathData.isInteractive && <title>{countryName}</title>}
    </path>
  );
};

const WorldMapView: React.FC<WorldMapViewProps> = ({ selectedRegionId, onSelectRegion, regionalData }) => {
  const allPaths = Object.entries(COUNTRY_PATHS).map(([id, path]) => ({
    id,
    path,
    isInteractive: !!regionalData[id],
  }));

  return (
    <div className="relative w-full h-full min-h-[150px] lg:min-h-0 bg-slate-100 rounded-lg p-2 border border-slate-200">
      <svg viewBox="580 80 350 450" className="w-full h-full">
        <rect width="1000" height="560" fill="transparent" />
        {allPaths.map((pathData) => {
          const region = regionalData[pathData.id];
          const score = region ? region.opportunityScore : 40;
          const name = region ? region.country : '';
          return (
            <CountryShape
              key={pathData.id}
              pathData={pathData}
              selected={selectedRegionId === pathData.id}
              onSelect={() => onSelectRegion(pathData.id)}
              score={score}
              countryName={name}
            />
          );
        })}
      </svg>
    </div>
  );
};

export default WorldMapView;
