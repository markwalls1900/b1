import React from 'react';
import WorldMapView from './WorldMapView';
import { REPORT_TIERS } from '../constants';
import { UserType, RegionalData } from '../types';
import { QuestionMarkCircleIcon } from './Icons';

interface ActionPanelProps {
    onStartGeneration: (type: UserType) => void;
    onShowMethodology: () => void;
    regionalData: Record<string, RegionalData>;
    selectedRegionId: string;
    onSelectRegion: (id: string) => void;
}

const ActionPanel: React.FC<ActionPanelProps> = ({ onStartGeneration, onShowMethodology, regionalData, selectedRegionId, onSelectRegion }) => {
    return (
        <div className="flex flex-col h-full">
            <div>
                 <h1 className="text-xl font-extrabold text-slate-800">
                    BWGA Nexus
                </h1>
                <p className="text-sm text-slate-500">
                    The Global Intelligence Suite
                </p>
            </div>

            <div className="my-8">
                 <WorldMapView selectedRegionId={selectedRegionId} onSelectRegion={onSelectRegion} regionalData={regionalData} />
            </div>

            {/* CTA Section */}
            <div className="text-center">
                 <h3 className="text-base font-bold text-slate-800 mb-2">Generate Intelligence Brief</h3>
                 <p className="text-slate-500 mb-4 text-xs">Go beyond the dashboard with a deep-dive, AI-Human validated report.</p>
                 <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => onStartGeneration('business')} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-2 rounded-lg transition-colors shadow-lg hover:shadow-blue-500/20 text-sm">
                        For Business
                    </button>
                    <button onClick={() => onStartGeneration('government')} className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-2 rounded-lg transition-colors shadow-lg hover:shadow-green-500/20 text-sm">
                        For Government
                    </button>
                 </div>
            </div>

            <hr className="border-slate-200 my-6" />
            
            {/* Tiers Section */}
            <div>
                <h3 className="text-base font-semibold text-slate-800 mb-3">Available Report Tiers</h3>
                <div className="space-y-3">
                    {REPORT_TIERS.map(tier => (
                        <div key={tier.id} className="bg-slate-100 p-3 rounded-lg text-left border border-slate-200">
                            <p className="font-bold text-sm text-blue-800">{tier.name}</p>
                            <p className="text-xs text-slate-500">{tier.description}</p>
                            <p className="text-xs font-semibold text-slate-600 mt-1">{tier.price}</p>
                        </div>
                    ))}
                </div>
            </div>
            
            <div className="mt-auto pt-6 text-xs text-slate-500">
                <h4 className="font-semibold text-slate-600 mb-1">What is BWGA Nexus?</h4>
                <p>
                    An AI-powered platform designed to de-risk regional investment by providing deep, actionable intelligence on overlooked markets.
                </p>
                <button onClick={onShowMethodology} className="mt-2 text-blue-600 hover:text-blue-800 font-semibold flex items-center space-x-1">
                    <QuestionMarkCircleIcon />
                    <span>View Our Methodology</span>
                </button>
            </div>
        </div>
    );
};

export default ActionPanel;
