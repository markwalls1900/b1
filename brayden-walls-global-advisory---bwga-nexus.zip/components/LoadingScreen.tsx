import React from 'react';
import { GlobeAltIcon, ChartBarIcon, ShieldCheckIcon, DocumentTextIcon } from './Icons';

const DATA_SOURCES = [
  { name: 'World Bank Open Data', logo: <GlobeAltIcon className="h-6 w-6" /> },
  { name: 'IMF Economic Data', logo: <ChartBarIcon className="h-6 w-6" /> },
  { name: 'Transparency International', logo: <ShieldCheckIcon className="h-6 w-6" /> },
  { name: 'Local Gov. Publications', logo: <DocumentTextIcon className="h-6 w-6" /> },
];


const LoadingScreen: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto text-center py-12 flex flex-col items-center justify-center min-h-screen">
      <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-slate-300 border-t-blue-600"></div>
      <h2 className="mt-6 text-2xl font-bold text-slate-900">Running Nexus AI Engine...</h2>
      <p className="mt-2 text-slate-500">Cross-referencing global data streams and applying NSIL™ logic.</p>
      
      <div className="mt-12 w-full max-w-lg">
        <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Analyzing Data From</h3>
        <div className="mt-4 flex justify-center items-center gap-8 flex-wrap">
          {DATA_SOURCES.map(source => (
            <div key={source.name} className="flex items-center space-x-2 text-slate-500" title={source.name}>
              {React.cloneElement(source.logo, { className: "h-6 w-6"})}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;
