import React from 'react';
import { RegionalData } from '../types';

interface ExecutiveBriefingViewProps {
    region: RegionalData;
    briefing: string | undefined;
    isLoading: boolean;
}

const ExecutiveBriefingView: React.FC<ExecutiveBriefingViewProps> = ({ region, briefing, isLoading }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
            <div className="flex-shrink-0 mb-4">
                <h2 className="text-xl font-bold text-slate-900 flex items-center">
                   <span className="mr-3 text-2xl">{region.countryCode.toUpperCase().replace(/./g, char => String.fromCodePoint(char.charCodeAt(0) + 127397))}</span>
                   NSIL™ Executive Briefing: {region.name}, {region.country}
                </h2>
                <p className="text-sm text-slate-500">AI-Synthesized Overview of the Current Investment Landscape</p>
            </div>

            <div className="prose prose-sm max-w-none prose-p:text-slate-600 prose-strong:text-slate-900 min-h-[140px]">
                {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                        <div className="text-center">
                            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-slate-300 border-t-blue-600"></div>
                            <p className="mt-3 text-sm text-slate-500">Synthesizing Data...</p>
                        </div>
                    </div>
                ) : (
                    <div dangerouslySetInnerHTML={{ __html: briefing || '' }} />
                )}
            </div>
        </div>
    );
};

export default ExecutiveBriefingView;
