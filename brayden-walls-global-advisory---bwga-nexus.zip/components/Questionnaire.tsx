import React from 'react';
import { UserType, InvestmentParams } from '../types';
import { DIALOGUE_QUESTIONS } from '../constants';

interface QuestionnaireProps {
  userType: UserType;
  onSubmit: (data: Omit<InvestmentParams, 'dimensionScores'>) => void;
  onBack: () => void;
}

const Questionnaire: React.FC<QuestionnaireProps> = ({ userType, onSubmit, onBack }) => {
  const questions = DIALOGUE_QUESTIONS[userType];

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const data = Object.fromEntries(formData.entries());
    onSubmit(data as Omit<InvestmentParams, 'dimensionScores'>);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl mx-auto bg-white text-slate-800 p-8 rounded-xl shadow-lg border border-slate-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Nexus Dialogue: Build Your Strategic Profile</h2>
          <p className="text-slate-500 mb-8">Answer these questions to provide the AI with the necessary context for its analysis.</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {questions.map((q) => (
              <div key={q.id}>
                <label htmlFor={q.id} className="block text-sm font-medium text-slate-700 mb-1">
                  {q.label}
                </label>
                {q.type === 'select' ? (
                  <select
                    name={q.id}
                    id={q.id}
                    required
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="">Select an option...</option>
                    {q.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                ) : (
                  <input
                    type="text"
                    name={q.id}
                    id={q.id}
                    required
                    placeholder={q.placeholder}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                )}
              </div>
            ))}

            <div className="flex items-center justify-between pt-4">
               <button type="button" onClick={onBack} className="text-sm text-slate-600 hover:text-slate-900 font-semibold">
                &larr; Back to Dashboard
              </button>
              <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-300 shadow-md">
                Generate Report
              </button>
            </div>
          </form>
        </div>
    </div>
  );
};

export default Questionnaire;
