import React from 'react';
import RegionalDetailView from './RegionalDetailView';
import ActionPanel from './ActionPanel';
import { RegionalData, UserType } from '../types';

interface DashboardProps {
    onStartGeneration: (type: UserType) => void;
    selectedRegionId: string;
    onSelectRegion: (id: string) => void;
    regionalData: Record<string, RegionalData>;
    isBriefingLoading: boolean;
    onShowMethodology: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onStartGeneration, selectedRegionId, onSelectRegion, regionalData, isBriefingLoading, onShowMethodology }) => {
    const selectedRegionData = regionalData[selectedRegionId];

    return (
        <div className="flex min-h-screen">
            <aside className="w-full max-w-xs xl:max-w-sm flex-shrink-0 bg-white border-r border-slate-200 p-6 space-y-8">
                <ActionPanel 
                    onStartGeneration={onStartGeneration} 
                    onShowMethodology={onShowMethodology}
                    regionalData={regionalData}
                    selectedRegionId={selectedRegionId}
                    onSelectRegion={onSelectRegion}
                />
            </aside>
            <div className="flex-1 p-6 lg:p-10 overflow-y-auto bg-slate-50">
                 <header className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-900">Global Intelligence Dashboard</h1>
                    <p className="text-slate-500 mt-1">Select a region on the map to view its strategic profile.</p>
                </header>
                <section>
                    {selectedRegionData && (
                        <RegionalDetailView 
                            region={selectedRegionData} 
                            briefing={selectedRegionData.briefing} 
                            isLoading={isBriefingLoading} 
                        />
                    )}
                </section>
            </div>
        </div>
    );
};

export default Dashboard;
