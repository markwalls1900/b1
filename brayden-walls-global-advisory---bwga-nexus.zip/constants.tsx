import { QuestionnaireQuestion, ReportTier, RegionalData, UserType } from './types';
import React from 'react';
import { GlobeAltIcon, ChartBarIcon, ScaleIcon, UserGroupIcon, ShieldCheckIcon, WifiIcon, DocumentTextIcon, QuestionMarkCircleIcon } from './components/Icons';

export const REPORT_TIERS: ReportTier[] = [
    {
        id: 'tier1', name: 'Strategic Brief', price: '$2,500 USD',
        description: 'High-level validation for a strong opportunity.',
        features: ['URP Index Analysis', 'Human Intelligence Overlay', 'Policy Mapping'],
    },
    {
        id: 'tier2', name: 'Partnership Facilitator', price: '$7,000 USD',
        description: 'A direct playbook for complex engagement.',
        features: ['All Tier 1 features', 'Engagement Playbook', 'Partner Matchmaking'],
    },
    {
        id: 'tier3', name: 'Transformation Simulator', price: '$25,000+ USD',
        description: 'For national-level ambitions and policy alignment.',
        features: ['All Tier 2 features', 'Economic Modeling', 'Policy Simulation'],
    }
];

export const REGIONAL_DATA: Record<string, RegionalData> = {
    philippines: {
        id: 'philippines', name: "Mindanao", country: "Philippines", countryCode: "PH",
        opportunityScore: 82,
        riskFactor: "Logistical challenges outside major hubs.",
        kpis: {
            gdpGrowth: { value: "5.9%", trend: "up", description: "Projected annual GDP growth." },
            fdiInflow: { value: "$9.2B", trend: "stable", description: "Previous year's foreign direct investment." },
            unemploymentRate: { value: "4.5%", trend: "down", description: "National unemployment rate." },
            easeOfBusiness: { value: 65, trend: "up", description: "Ease of Doing Business score (1-100)." },
            corruptionPerception: { value: 33, trend: "stable", description: "Corruption Perception Index (1-100)." },
            internetSpeed: { value: "55 Mbps", trend: "up", description: "Average fixed broadband speed." },
        }
    },
    vietnam: {
        id: 'vietnam', name: "Da Nang", country: "Vietnam", countryCode: "VN",
        opportunityScore: 91,
        riskFactor: "Rising competition for high-skilled labor.",
         kpis: {
            gdpGrowth: { value: "6.5%", trend: "up", description: "Projected annual GDP growth." },
            fdiInflow: { value: "$15.8B", trend: "up", description: "Previous year's foreign direct investment." },
            unemploymentRate: { value: "2.3%", trend: "stable", description: "National unemployment rate." },
            easeOfBusiness: { value: 70, trend: "up", description: "Ease of Doing Business score (1-100)." },
            corruptionPerception: { value: 42, trend: "up", description: "Corruption Perception Index (1-100)." },
            internetSpeed: { value: "80 Mbps", trend: "up", description: "Average fixed broadband speed." },
        }
    },
    indonesia: {
        id: 'indonesia', name: "East Java", country: "Indonesia", countryCode: "ID",
        opportunityScore: 78,
        riskFactor: "Regulatory complexity and logistical challenges.",
        kpis: {
            gdpGrowth: { value: "5.1%", trend: "stable", description: "Projected annual GDP growth." },
            fdiInflow: { value: "$21.4B", trend: "up", description: "Previous year's foreign direct investment." },
            unemploymentRate: { value: "5.8%", trend: "down", description: "National unemployment rate." },
            easeOfBusiness: { value: 60, trend: "stable", description: "Ease of Doing Business score (1-100)." },
            corruptionPerception: { value: 34, trend: "stable", description: "Corruption Perception Index (1-100)." },
            internetSpeed: { value: "25 Mbps", trend: "up", description: "Average fixed broadband speed." },
        }
    },
    malaysia: {
        id: 'malaysia', name: "Penang", country: "Malaysia", countryCode: "MY",
        opportunityScore: 89,
        riskFactor: "Dependency on the global tech cycle.",
        kpis: {
            gdpGrowth: { value: "4.7%", trend: "stable", description: "Projected annual GDP growth." },
            fdiInflow: { value: "$17.1B", trend: "stable", description: "Previous year's foreign direct investment." },
            unemploymentRate: { value: "3.6%", trend: "stable", description: "National unemployment rate." },
            easeOfBusiness: { value: 81, trend: "up", description: "Ease of Doing Business score (1-100)." },
            corruptionPerception: { value: 50, trend: "stable", description: "Corruption Perception Index (1-100)." },
            internetSpeed: { value: "95 Mbps", trend: "up", description: "Average fixed broadband speed." },
        }
    }
};

export const DIALOGUE_QUESTIONS: Record<UserType, QuestionnaireQuestion[]> = {
  business: [
    { id: 'organization', label: 'What is your organization\'s name?', type: 'text', placeholder: 'e.g., Apex Global Corp' },
    { id: 'country', label: 'Which country are you primarily interested in?', type: 'select', options: ['Philippines', 'Vietnam', 'Indonesia', 'Malaysia'] },
    { id: 'industry', label: 'What industry are you operating in?', type: 'text', placeholder: 'e.g., Renewable Energy, Manufacturing' },
    { id: 'objective', label: 'What is your primary investment objective?', type: 'text', placeholder: 'e.g., Establish a regional supply chain hub' },
    { id: 'dealbreaker', label: 'What is a critical dealbreaker for this investment?', type: 'text', placeholder: 'e.g., Unstable power grid, excessive corruption' },
  ],
  government: [
    { id: 'organization', label: 'What is your agency or department\'s name?', type: 'text', placeholder: 'e.g., National Economic and Development Authority' },
    { id: 'country', label: 'Which region do you represent?', type: 'select', options: ['Philippines', 'Vietnam', 'Indonesia', 'Malaysia'] },
    { id: 'industry', label: 'Which industry are you aiming to attract investment into?', type: 'text', placeholder: 'e.g., High-Tech Manufacturing, Agri-Tech' },
    { id: 'objective', label: 'What is your primary development objective?', type: 'text', placeholder: 'e.g., Attract $500M in Foreign Direct Investment' },
    { id: 'dealbreaker', label: 'What is the biggest hurdle for investors in your region?', type: 'text', placeholder: 'e.g., Bureaucratic red tape, skills gap' },
  ],
};
