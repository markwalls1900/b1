import { GoogleGenAI } from "@google/genai";
import type { RegionalData } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using mock data.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "mock-key" });

const generateMockBriefing = (region: RegionalData): string => {
    return `This is a mock **Executive Briefing** for **${region.name}, ${region.country}**.
    
The region presents a compelling opportunity, underscored by an Opportunity Score of **${region.opportunityScore}**. The positive outlook is supported by strong GDP Growth of **${region.kpis.gdpGrowth.value}** and a business-friendly environment as indicated by the Ease of Doing Business score of **${region.kpis.easeOfBusiness.value}**.
    
However, investors should be mindful of the primary risk identified: *${region.riskFactor}*. The Corruption Perception Index of **${region.kpis.corruptionPerception.value}** suggests that navigating the local bureaucracy may require careful due diligence. This simulated response highlights how NSIL™ provides at-a-glance strategic insights on the dashboard.`;
}

export async function generateDashboardBriefing(region: RegionalData): Promise<string> {
    if (!process.env.API_KEY) {
        return Promise.resolve(generateMockBriefing(region).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />'));
    }

    const systemInstruction = `You are NSIL™ (Nexus Symbiotic Intelligence Language), the proprietary AI of BWGA Nexus. Your task is to generate a concise, professional, and insightful **Executive Briefing** for a selected region on a global dashboard.
- You will receive a JSON object containing structured data about a region, including Key Performance Indicators (KPIs) with values and trends.
- Your output must be a 2-paragraph strategic summary.
- **Paragraph 1:** Start with a strong opening statement synthesizing the overall opportunity, referencing the **Opportunity Score**. Weave in the most positive KPIs (e.g., high GDP Growth, FDI Inflow, Ease of Business) as evidence for the optimistic outlook. Mention the trend direction where relevant (e.g., "robust GDP growth, which is trending upwards").
- **Paragraph 2:** Provide a balanced view. Start with the primary risk factor summary from the 'riskFactor' field. Then, use the less favorable KPIs (e.g., high Unemployment, low Corruption Perception score) to add nuance and specific detail to the risk assessment.
- Use markdown for emphasis on names, countries, and key scores/terms (e.g. **Mindanao**, **Opportunity Score of 82**).
- The tone must be authoritative and strategic, as if briefing a C-suite executive. Directly connect the data points to strategic implications.`;

    const prompt = `
Generate an NSIL™ Executive Briefing for the dashboard based on this structured data:
\`\`\`json
${JSON.stringify(region, null, 2)}
\`\`\`
`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: { systemInstruction },
        });
        return response.text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />');
    } catch (error) {
        console.error("Gemini API call for dashboard briefing failed:", error);
        return generateMockBriefing(region).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br />');
    }
}
