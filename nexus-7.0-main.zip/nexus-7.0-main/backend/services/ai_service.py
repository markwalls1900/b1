"""
AI Service - Handles forecasting, analysis, and AI insights
"""

import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Any, List
import random

class AIService:
    def __init__(self):
        self.forecast_models = {}
        self.analysis_cache = {}

    async def analyze_region(self, country_code: str, region_name: str, 
                           economic_data: Dict[str, Any], risk_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze a region and provide AI insights"""
        
        # Generate AI insights based on economic and risk data
        gdp_growth = economic_data.get("gdp_growth", 2.0)
        inflation = economic_data.get("inflation_rate", 3.0)
        
        # Determine investment opportunities
        opportunities = []
        if gdp_growth > 3.0:
            opportunities.append("High growth potential for expansion")
        if inflation < 2.0:
            opportunities.append("Stable economic environment")
        if gdp_growth > 2.0 and inflation < 4.0:
            opportunities.append("Balanced growth and stability")
        
        # Market trends
        trends = [
            "Digital transformation accelerating",
            "Sustainable investment gaining traction",
            "Regional economic integration increasing"
        ]
        
        # Competitive advantages
        advantages = [
            "Strategic geographic location",
            "Skilled workforce availability",
            "Supportive regulatory environment"
        ]
        
        # Strategic recommendations
        recommendations = []
        if gdp_growth > 2.5:
            recommendations.append("Consider aggressive expansion strategy")
        if risk_data.get("overall_risk", "MEDIUM") == "LOW":
            recommendations.append("Favorable risk profile for investment")
        recommendations.append("Focus on technology and innovation sectors")
        
        # Risk mitigation
        mitigation = [
            "Diversify investment portfolio",
            "Monitor regulatory changes",
            "Establish local partnerships"
        ]
        
        return {
            "investment_opportunities": opportunities,
            "market_trends": trends,
            "competitive_advantages": advantages,
            "strategic_recommendations": recommendations,
            "risk_mitigation": mitigation,
            "confidence_score": 0.85
        }

    async def forecast_growth(self, country_code: str, region_name: str, 
                            economic_data: Dict[str, Any]) -> Dict[str, Any]:
        """Forecast growth for a region"""
        
        gdp_growth = economic_data.get("gdp_growth", 2.0)
        inflation = economic_data.get("inflation_rate", 3.0)
        
        # Calculate growth forecasts based on economic indicators
        base_growth = gdp_growth
        
        # Short-term forecast (1-2 years)
        short_term = base_growth + random.uniform(-0.5, 1.0)
        
        # Medium-term forecast (3-5 years)
        medium_term = base_growth + random.uniform(-1.0, 2.0)
        
        # Long-term forecast (5-10 years)
        long_term = base_growth + random.uniform(-1.5, 3.0)
        
        # Growth factors
        growth_factors = []
        if gdp_growth > 2.0:
            growth_factors.append("Strong economic fundamentals")
        if inflation < 3.0:
            growth_factors.append("Price stability")
        growth_factors.append("Technological advancement")
        growth_factors.append("Global market integration")
        
        # Potential obstacles
        obstacles = []
        if inflation > 4.0:
            obstacles.append("Inflationary pressures")
        if gdp_growth < 1.5:
            obstacles.append("Slow economic growth")
        obstacles.append("Geopolitical uncertainties")
        obstacles.append("Climate change impacts")
        
        return {
            "short_term_growth": round(short_term, 2),
            "medium_term_growth": round(medium_term, 2),
            "long_term_growth": round(long_term, 2),
            "confidence_level": 0.78,
            "growth_factors": growth_factors,
            "potential_obstacles": obstacles
        }

    async def get_forecast(self, country_code: str, region: str = None, 
                          industry: str = None) -> Dict[str, Any]:
        """Get comprehensive forecast for country/region/industry"""
        
        # Base forecast data
        forecast_data = {
            "country_code": country_code,
            "region": region,
            "industry": industry,
            "forecast_period": "2024-2030",
            "generated_at": datetime.now().isoformat()
        }
        
        # Economic indicators
        economic_indicators = {
            "gdp_growth_forecast": round(random.uniform(1.5, 4.0), 2),
            "inflation_forecast": round(random.uniform(1.0, 5.0), 2),
            "employment_growth": round(random.uniform(0.5, 3.0), 2),
            "investment_growth": round(random.uniform(2.0, 8.0), 2)
        }
        
        # Industry-specific forecasts
        industry_forecasts = {
            "Technology": {"growth": 8.5, "risk": "LOW", "opportunity": "HIGH"},
            "Finance": {"growth": 4.2, "risk": "MEDIUM", "opportunity": "MEDIUM"},
            "Manufacturing": {"growth": 3.1, "risk": "MEDIUM", "opportunity": "MEDIUM"},
            "Healthcare": {"growth": 6.8, "risk": "LOW", "opportunity": "HIGH"},
            "Energy": {"growth": 5.2, "risk": "HIGH", "opportunity": "HIGH"},
            "Retail": {"growth": 3.8, "risk": "MEDIUM", "opportunity": "MEDIUM"}
        }
        
        if industry and industry in industry_forecasts:
            forecast_data["industry_forecast"] = industry_forecasts[industry]
        
        forecast_data["economic_indicators"] = economic_indicators
        forecast_data["confidence_level"] = 0.82
        
        return forecast_data

    async def calculate_investment_potential(self, country_code: str, 
                                           region: str = None, 
                                           industry: str = None) -> Dict[str, Any]:
        """Calculate investment potential score"""
        
        # Base potential score
        base_score = 70
        
        # Adjust based on country
        country_adjustments = {
            "US": 15, "GB": 10, "DE": 12, "JP": 8, 
            "CN": 20, "IN": 18, "BR": 5, "AU": 8
        }
        base_score += country_adjustments.get(country_code, 0)
        
        # Adjust based on industry
        industry_adjustments = {
            "Technology": 20, "Finance": 10, "Manufacturing": 5,
            "Healthcare": 15, "Energy": 8, "Retail": 3
        }
        if industry:
            base_score += industry_adjustments.get(industry, 0)
        
        # Final score with some randomness
        final_score = min(100, max(0, base_score + random.uniform(-10, 10)))
        
        return {
            "investment_potential_score": round(final_score, 1),
            "risk_level": "LOW" if final_score > 80 else "MEDIUM" if final_score > 60 else "HIGH",
            "recommendation": "STRONG BUY" if final_score > 85 else "BUY" if final_score > 70 else "HOLD" if final_score > 50 else "SELL"
        } 