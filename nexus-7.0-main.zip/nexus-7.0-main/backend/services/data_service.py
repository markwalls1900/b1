"""
Data Service - Handles real-time data fetching from various APIs
"""

import asyncio
import aiohttp
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import os
from dotenv import load_dotenv

load_dotenv()

class DataService:
    def __init__(self):
        self.session = None
        self.cache = {}
        self.cache_duration = timedelta(minutes=15)
        
        # API Keys (in production, use environment variables)
        self.world_bank_api_key = os.getenv("WORLD_BANK_API_KEY", "demo")
        self.google_api_key = os.getenv("GOOGLE_API_KEY", "demo")
        self.weather_api_key = os.getenv("OPENWEATHER_API_KEY", "demo")
        
        # Sample data for demo purposes
        self.sample_countries = [
            {"code": "US", "name": "United States", "region": "North America", "gdp": 25462700, "population": 331002651, "currency": "USD"},
            {"code": "GB", "name": "United Kingdom", "region": "Europe", "gdp": 3070667, "population": 67886011, "currency": "GBP"},
            {"code": "DE", "name": "Germany", "region": "Europe", "gdp": 4072191, "population": 83190556, "currency": "EUR"},
            {"code": "JP", "name": "Japan", "region": "Asia", "gdp": 4231141, "population": 125836021, "currency": "JPY"},
            {"code": "CN", "name": "China", "region": "Asia", "gdp": 17963170, "population": 1439323776, "currency": "CNY"},
            {"code": "IN", "name": "India", "region": "Asia", "gdp": 3385089, "population": 1380004385, "currency": "INR"},
            {"code": "BR", "name": "Brazil", "region": "South America", "gdp": 1920095, "population": 212559417, "currency": "BRL"},
            {"code": "AU", "name": "Australia", "region": "Oceania", "gdp": 1675418, "population": 25499884, "currency": "AUD"},
        ]
        
        self.sample_regions = {
            "US": [
                {"name": "California", "population": 39512223, "gdp_per_capita": 85000, "growth_rate": 2.1, "key_industries": ["Technology", "Entertainment", "Agriculture"]},
                {"name": "Texas", "population": 28995881, "gdp_per_capita": 65000, "growth_rate": 1.8, "key_industries": ["Energy", "Technology", "Manufacturing"]},
                {"name": "New York", "population": 19453561, "gdp_per_capita": 75000, "growth_rate": 1.5, "key_industries": ["Finance", "Technology", "Healthcare"]},
            ],
            "GB": [
                {"name": "London", "population": 8982000, "gdp_per_capita": 55000, "growth_rate": 1.2, "key_industries": ["Finance", "Technology", "Creative"]},
                {"name": "Manchester", "population": 2553379, "gdp_per_capita": 35000, "growth_rate": 1.8, "key_industries": ["Technology", "Manufacturing", "Education"]},
            ],
            "DE": [
                {"name": "Berlin", "population": 3669491, "gdp_per_capita": 45000, "growth_rate": 2.0, "key_industries": ["Technology", "Creative", "Manufacturing"]},
                {"name": "Munich", "population": 1484226, "gdp_per_capita": 60000, "growth_rate": 1.5, "key_industries": ["Technology", "Automotive", "Finance"]},
            ]
        }
        
        self.sample_industries = [
            {"code": "TECH", "name": "Technology", "description": "Software, hardware, and digital services", "growth_potential": 0.85, "risk_level": "LOW"},
            {"code": "FIN", "name": "Finance", "description": "Banking, insurance, and financial services", "growth_potential": 0.65, "risk_level": "MEDIUM"},
            {"code": "MANUF", "name": "Manufacturing", "description": "Industrial production and manufacturing", "growth_potential": 0.45, "risk_level": "MEDIUM"},
            {"code": "HEALTH", "name": "Healthcare", "description": "Medical services and biotechnology", "growth_potential": 0.75, "risk_level": "LOW"},
            {"code": "ENERGY", "name": "Energy", "description": "Oil, gas, and renewable energy", "growth_potential": 0.60, "risk_level": "HIGH"},
            {"code": "RETAIL", "name": "Retail", "description": "Consumer goods and e-commerce", "growth_potential": 0.55, "risk_level": "MEDIUM"},
        ]

    async def get_session(self):
        """Get or create aiohttp session"""
        if self.session is None:
            self.session = aiohttp.ClientSession()
        return self.session

    async def get_countries(self) -> List[Dict[str, Any]]:
        """Get list of available countries"""
        # For demo, return sample data
        # In production, this would fetch from World Bank API
        return self.sample_countries

    async def get_regions(self, country_code: str) -> List[Dict[str, Any]]:
        """Get regions for a specific country"""
        # For demo, return sample data
        # In production, this would fetch from government APIs
        return self.sample_regions.get(country_code, [])

    async def get_economic_data(self, country_code: str) -> Dict[str, Any]:
        """Get economic indicators for a country"""
        # For demo, generate realistic sample data
        # In production, this would fetch from World Bank, IMF, etc.
        
        base_data = {
            "US": {"gdp_growth": 2.1, "inflation": 3.2, "unemployment": 3.7},
            "GB": {"gdp_growth": 1.8, "inflation": 4.0, "unemployment": 4.2},
            "DE": {"gdp_growth": 1.5, "inflation": 2.8, "unemployment": 3.1},
            "JP": {"gdp_growth": 1.2, "inflation": 0.5, "unemployment": 2.6},
            "CN": {"gdp_growth": 5.2, "inflation": 2.1, "unemployment": 5.1},
            "IN": {"gdp_growth": 6.8, "inflation": 5.5, "unemployment": 7.2},
            "BR": {"gdp_growth": 2.9, "inflation": 4.8, "unemployment": 8.9},
            "AU": {"gdp_growth": 2.4, "inflation": 3.1, "unemployment": 3.8},
        }
        
        country_data = base_data.get(country_code, {"gdp_growth": 2.0, "inflation": 3.0, "unemployment": 5.0})
        
        return {
            "gdp_growth": country_data["gdp_growth"],
            "inflation_rate": country_data["inflation"],
            "unemployment_rate": country_data["unemployment"],
            "foreign_investment": round(country_data["gdp_growth"] * 0.3, 2),
            "trade_balance": round(country_data["gdp_growth"] * 0.1, 2),
            "currency_stability": round(100 - country_data["inflation"], 1),
            "last_updated": datetime.now().isoformat()
        }

    async def get_industries(self) -> List[Dict[str, Any]]:
        """Get list of available industries"""
        return self.sample_industries

    async def get_dashboard_stats(self) -> Dict[str, Any]:
        """Get dashboard statistics and overview"""
        return {
            "total_countries": len(self.sample_countries),
            "total_regions": sum(len(regions) for regions in self.sample_regions.values()),
            "total_industries": len(self.sample_industries),
            "reports_generated": 156,
            "total_value_created": 2847500.00,
            "average_roi": 0.23
        }

    async def fetch_world_bank_data(self, country_code: str, indicator: str) -> Dict[str, Any]:
        """Fetch data from World Bank API"""
        try:
            session = await self.get_session()
            url = f"http://api.worldbank.org/v2/country/{country_code}/indicator/{indicator}?format=json&per_page=1"
            
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
                else:
                    return {"error": f"Failed to fetch data: {response.status}"}
        except Exception as e:
            return {"error": f"API call failed: {str(e)}"}

    async def fetch_google_trends(self, query: str) -> Dict[str, Any]:
        """Fetch Google Trends data"""
        # In production, this would use Google Trends API
        return {
            "query": query,
            "trend_score": 75,
            "rising_queries": ["investment opportunities", "economic growth", "market analysis"],
            "related_topics": ["finance", "business", "economy"]
        }

    async def fetch_weather_data(self, city: str, country_code: str) -> Dict[str, Any]:
        """Fetch weather data for risk assessment"""
        try:
            session = await self.get_session()
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city},{country_code}&appid={self.weather_api_key}&units=metric"
            
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "temperature": data["main"]["temp"],
                        "humidity": data["main"]["humidity"],
                        "weather_condition": data["weather"][0]["main"],
                        "risk_level": self._assess_weather_risk(data)
                    }
                else:
                    return {"error": f"Weather API failed: {response.status}"}
        except Exception as e:
            return {"error": f"Weather API call failed: {str(e)}"}

    def _assess_weather_risk(self, weather_data: Dict[str, Any]) -> str:
        """Assess weather-related risk level"""
        temp = weather_data["main"]["temp"]
        weather = weather_data["weather"][0]["main"].lower()
        
        if weather in ["storm", "hurricane", "tornado"]:
            return "HIGH"
        elif temp > 40 or temp < -20:
            return "MEDIUM"
        else:
            return "LOW"

    async def close(self):
        """Close the session"""
        if self.session:
            await self.session.close() 