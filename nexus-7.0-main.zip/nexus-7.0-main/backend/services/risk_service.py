"""
Risk Service - Handles risk assessment and analysis
"""

from datetime import datetime
from typing import Dict, Any, List
import random

class RiskService:
    def __init__(self):
        self.risk_models = {}
        self.risk_cache = {}

    async def assess_risks(self, country_code: str, region_name: str = None) -> Dict[str, Any]:
        """Assess risks for a country/region"""
        
        # Base risk levels by country
        country_risk_base = {
            "US": {"political": "LOW", "economic": "LOW", "environmental": "MEDIUM"},
            "GB": {"political": "LOW", "economic": "MEDIUM", "environmental": "LOW"},
            "DE": {"political": "LOW", "economic": "LOW", "environmental": "LOW"},
            "JP": {"political": "LOW", "economic": "MEDIUM", "environmental": "HIGH"},
            "CN": {"political": "MEDIUM", "economic": "MEDIUM", "environmental": "HIGH"},
            "IN": {"political": "MEDIUM", "economic": "MEDIUM", "environmental": "HIGH"},
            "BR": {"political": "MEDIUM", "economic": "MEDIUM", "environmental": "MEDIUM"},
            "AU": {"political": "LOW", "economic": "LOW", "environmental": "HIGH"}
        }
        
        base_risks = country_risk_base.get(country_code, {
            "political": "MEDIUM", "economic": "MEDIUM", "environmental": "MEDIUM"
        })
        
        # Add some variability
        political_risk = self._adjust_risk_level(base_risks["political"])
        economic_risk = self._adjust_risk_level(base_risks["economic"])
        environmental_risk = self._adjust_risk_level(base_risks["environmental"])
        
        # Infrastructure risk (generally lower for developed countries)
        infrastructure_risk = "LOW" if country_code in ["US", "GB", "DE", "JP", "AU"] else "MEDIUM"
        
        # Regulatory risk
        regulatory_risk = "LOW" if country_code in ["US", "GB", "DE"] else "MEDIUM"
        
        # Calculate overall risk
        risk_levels = [political_risk, economic_risk, environmental_risk, infrastructure_risk, regulatory_risk]
        overall_risk = self._calculate_overall_risk(risk_levels)
        
        # Risk factors
        risk_factors = self._generate_risk_factors(country_code, region_name, risk_levels)
        
        return {
            "political_risk": political_risk,
            "economic_risk": economic_risk,
            "environmental_risk": environmental_risk,
            "infrastructure_risk": infrastructure_risk,
            "regulatory_risk": regulatory_risk,
            "overall_risk": overall_risk,
            "risk_factors": risk_factors,
            "assessment_date": datetime.now().isoformat()
        }

    async def get_risks(self, country_code: str, region: str = None) -> Dict[str, Any]:
        """Get detailed risk assessment"""
        return await self.assess_risks(country_code, region)

    def _adjust_risk_level(self, base_level: str) -> str:
        """Add some randomness to risk levels"""
        levels = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
        current_index = levels.index(base_level)
        
        # 70% chance to stay the same, 30% chance to adjust
        if random.random() < 0.7:
            return base_level
        else:
            # Adjust up or down by 1 level
            adjustment = random.choice([-1, 1])
            new_index = max(0, min(len(levels) - 1, current_index + adjustment))
            return levels[new_index]

    def _calculate_overall_risk(self, risk_levels: List[str]) -> str:
        """Calculate overall risk based on individual risk levels"""
        level_scores = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}
        scores = [level_scores[level] for level in risk_levels]
        average_score = sum(scores) / len(scores)
        
        if average_score <= 1.5:
            return "LOW"
        elif average_score <= 2.5:
            return "MEDIUM"
        elif average_score <= 3.5:
            return "HIGH"
        else:
            return "CRITICAL"

    def _generate_risk_factors(self, country_code: str, region_name: str, risk_levels: List[str]) -> List[str]:
        """Generate specific risk factors"""
        factors = []
        
        # Political risk factors
        if "HIGH" in risk_levels or "CRITICAL" in risk_levels:
            factors.append("Political instability concerns")
            factors.append("Regulatory uncertainty")
        
        # Economic risk factors
        if country_code in ["CN", "IN", "BR"]:
            factors.append("Currency volatility")
            factors.append("Economic policy changes")
        
        # Environmental risk factors
        if country_code in ["JP", "AU"]:
            factors.append("Natural disaster exposure")
        
        # Infrastructure risk factors
        if country_code in ["IN", "BR"]:
            factors.append("Infrastructure development needs")
        
        # Add some general factors
        factors.extend([
            "Global economic uncertainty",
            "Supply chain disruptions",
            "Climate change impacts"
        ])
        
        return factors[:5]  # Return top 5 factors 