#!/usr/bin/env python3
"""
Startup script for the Global Investment Intelligence Dashboard Backend
"""

import uvicorn
import sys
import os

# Add the backend directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from main import app

if __name__ == "__main__":
    print("🚀 Starting Global Investment Intelligence Dashboard Backend...")
    print("=" * 60)
    print("📊 API Documentation: http://localhost:8000/docs")
    print("🌐 Dashboard: http://localhost:8000")
    print("🔍 Health Check: http://localhost:8000/api/health")
    print("📈 Sample Endpoints:")
    print("   - GET /api/countries")
    print("   - GET /api/economic-data/US")
    print("   - POST /api/analyze-region")
    print("   - POST /api/generate-report")
    print("=" * 60)
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    ) 