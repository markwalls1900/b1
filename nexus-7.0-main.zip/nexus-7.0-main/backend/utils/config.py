"""
Configuration settings for the backend
"""

import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    # API Configuration
    API_TITLE = "Global Investment Intelligence Dashboard"
    API_VERSION = "1.0.0"
    API_DESCRIPTION = "Real-time investment analysis, forecasting, and risk assessment"
    
    # Server Configuration
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 8000))
    DEBUG = os.getenv("DEBUG", "True").lower() == "true"
    
    # Database Configuration
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./investment_dashboard.db")
    
    # API Keys (for production, these should be in environment variables)
    WORLD_BANK_API_KEY = os.getenv("WORLD_BANK_API_KEY", "demo")
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "demo")
    OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "demo")
    
    # Cache Configuration
    CACHE_DURATION = int(os.getenv("CACHE_DURATION", 900))  # 15 minutes
    
    # Security Configuration
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 30
    
    # CORS Configuration
    ALLOWED_ORIGINS = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
        "*"  # In production, specify your frontend domain
    ]
    
    # Report Configuration
    REPORT_TIERS = {
        "basic": {"price": 99, "value_multiplier": 1.0},
        "advanced": {"price": 299, "value_multiplier": 2.5},
        "premium": {"price": 599, "value_multiplier": 5.0},
        "enterprise": {"price": 1999, "value_multiplier": 15.0}
    }
    
    # Sample data configuration
    SAMPLE_COUNTRIES = [
        "US", "GB", "DE", "JP", "CN", "IN", "BR", "AU"
    ]
    
    SAMPLE_INDUSTRIES = [
        "Technology", "Finance", "Manufacturing", "Healthcare", "Energy", "Retail"
    ]

settings = Settings() 