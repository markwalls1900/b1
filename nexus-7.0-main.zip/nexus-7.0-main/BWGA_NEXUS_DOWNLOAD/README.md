# AI Dashboard - Comprehensive Analysis System

A powerful AI-powered dashboard system that processes binary files, generates comprehensive reports, and provides interactive Q&A functionality for workspace analysis.

## 🚀 Features

### 📊 **Comprehensive File Analysis**
- **Binary File Processing**: Converts and analyzes base64-encoded files
- **Multi-format Support**: HTML, CSS, JavaScript, and other text-based files
- **Content Extraction**: Intelligent text extraction from various file formats
- **File Metadata Analysis**: Size, modification dates, and structural information

### 🤖 **AI-Powered Analysis**
- **Sentiment Analysis**: Understand content emotional tone
- **Topic Extraction**: Identify key themes and subjects
- **Complexity Scoring**: Measure content sophistication
- **Entity Recognition**: Extract named entities and key terms
- **Keyword Analysis**: Identify important terms and phrases

### 📈 **Advanced Reporting**
- **Executive Summary**: High-level overview for decision makers
- **Technical Analysis**: Detailed technical insights
- **Interactive Reports**: Dynamic, real-time report generation
- **Visual Analytics**: Charts and graphs for data visualization

### 💬 **Interactive Q&A System**
- **Natural Language Processing**: Understand user questions
- **Context-Aware Responses**: Answers based on analyzed content
- **Suggested Questions**: Pre-built questions for common inquiries
- **Conversation History**: Track and review Q&A sessions

### 🎨 **Modern Dashboard Interface**
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Real-time Updates**: Live data and analysis updates
- **Interactive Charts**: Dynamic visualizations
- **User-friendly UI**: Intuitive navigation and controls

## 🛠️ Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Git (for cloning)

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ai-dashboard
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Download spaCy model**
   ```bash
   python -m spacy download en_core_web_sm
   ```

5. **Set up environment variables**
   ```bash
   # Create .env file
   echo "OPENAI_API_KEY=your_openai_api_key_here" > .env
   ```

## 🚀 Usage

### Starting the Dashboard

1. **Run the application**
   ```bash
   python ai_dashboard.py
   ```

2. **Access the dashboard**
   - Open your web browser
   - Navigate to `http://localhost:5000`
   - The dashboard will automatically scan your workspace

### Using the Dashboard

#### 1. **Overview Tab**
- View overall statistics and metrics
- Monitor analysis progress
- Access quick actions for common tasks

#### 2. **File Analysis Tab**
- Browse all files in your workspace
- Click on files to analyze their content
- View detailed analysis results including:
  - Sentiment scores
  - Complexity metrics
  - Keyword extraction
  - Entity recognition

#### 3. **AI Reports Tab**
- Generate executive summaries
- Create technical analysis reports
- Export reports in various formats

#### 4. **Q&A System Tab**
- Ask natural language questions about your content
- Get AI-powered answers based on analysis
- Use suggested questions for common inquiries
- Review conversation history

#### 5. **Settings Tab**
- Configure analysis parameters
- Adjust report depth and detail levels
- Enable/disable specific analysis features

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the project root:

```env
# OpenAI API Key (optional, for enhanced AI features)
OPENAI_API_KEY=your_openai_api_key_here

# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True

# Dashboard Configuration
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=5000
```

### Analysis Settings

You can configure analysis parameters in the Settings tab:

- **Sentiment Analysis**: Enable/disable emotional tone analysis
- **Topic Extraction**: Control keyword and theme identification
- **Complexity Analysis**: Adjust complexity scoring algorithms
- **Report Depth**: Choose between basic, detailed, or comprehensive reports
- **Max Files**: Set limit for files to analyze

## 📁 Project Structure

```
ai-dashboard/
├── ai_dashboard.py          # Main application file
├── requirements.txt         # Python dependencies
├── README.md               # This file
├── .env                    # Environment variables
├── templates/
│   └── dashboard.html      # Dashboard HTML template
├── static/
│   ├── css/               # Stylesheets
│   ├── js/                # JavaScript files
│   └── images/            # Image assets
└── data/
    └── reports/           # Generated reports
```

## 🔍 API Endpoints

### File Management
- `POST /api/scan` - Scan and categorize workspace files
- `POST /api/analyze` - Analyze specific file content

### Reports
- `GET /api/report/executive` - Generate executive summary
- `GET /api/report/technical` - Generate technical analysis

### Q&A System
- `POST /api/qa/ask` - Ask questions about content
- `GET /api/qa/history` - Get Q&A conversation history

## 🤖 AI Models Used

### Natural Language Processing
- **spaCy**: Named entity recognition and text processing
- **Transformers**: Sentiment analysis and text classification
- **scikit-learn**: TF-IDF keyword extraction and clustering

### Machine Learning
- **Torch**: Deep learning models for advanced analysis
- **NumPy**: Numerical computations and data processing
- **Pandas**: Data manipulation and analysis

## 📊 Report Types

### Executive Summary
- High-level overview of workspace content
- Key metrics and statistics
- Business insights and recommendations
- Visual charts and graphs

### Technical Analysis
- Detailed file structure analysis
- Content complexity assessment
- Code quality metrics (for programming files)
- Performance recommendations

### Interactive Q&A
- Common questions and answers
- Pattern analysis in user inquiries
- Suggested improvements based on usage
- Conversation analytics

## 🔒 Security Features

- **Input Validation**: All user inputs are validated and sanitized
- **Error Handling**: Comprehensive error handling and logging
- **Rate Limiting**: API rate limiting to prevent abuse
- **Secure Headers**: Security headers for web application protection

## 🐛 Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   # Reinstall dependencies
   pip install -r requirements.txt --force-reinstall
   ```

2. **spaCy Model Not Found**
   ```bash
   # Download the English model
   python -m spacy download en_core_web_sm
   ```

3. **Port Already in Use**
   ```bash
   # Change port in ai_dashboard.py
   dashboard.run(port=5001)
   ```

4. **Memory Issues**
   - Reduce `max-files` setting in dashboard
   - Process files in smaller batches

### Logging

Enable debug logging by setting:
```python
logging.basicConfig(level=logging.DEBUG)
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the GitHub repository
- Check the troubleshooting section
- Review the documentation

## 🔄 Updates

### Version 1.0.0
- Initial release with core functionality
- File analysis and AI-powered insights
- Interactive Q&A system
- Modern dashboard interface

### Planned Features
- Real-time collaboration
- Advanced visualization options
- Export to multiple formats
- Integration with external APIs
- Mobile application

---

**Built with ❤️ using Python, Flask, and modern AI technologies** 