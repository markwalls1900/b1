#!/usr/bin/env python3
"""
AI Dashboard Startup Script
Simple script to start the AI Dashboard with proper initialization
"""

import os
import sys
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def check_dependencies():
    """Check if required dependencies are installed"""
    required_packages = [
        'flask',
        'flask_socketio',
        'aiofiles',
        'transformers',
        'torch',
        'numpy',
        'scikit-learn',
        'spacy',
        'pandas',
        'matplotlib'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        logger.error(f"Missing required packages: {', '.join(missing_packages)}")
        logger.info("Please install missing packages using: pip install -r requirements.txt")
        return False
    
    return True

def check_spacy_model():
    """Check if spaCy English model is installed"""
    try:
        import spacy
        nlp = spacy.load("en_core_web_sm")
        logger.info("spaCy English model found")
        return True
    except OSError:
        logger.warning("spaCy English model not found")
        logger.info("To install: python -m spacy download en_core_web_sm")
        return False

def create_env_file():
    """Create .env file if it doesn't exist"""
    env_file = Path('.env')
    if not env_file.exists():
        logger.info("Creating .env file...")
        with open(env_file, 'w') as f:
            f.write("# AI Dashboard Environment Variables\n")
            f.write("# Add your OpenAI API key here (optional)\n")
            f.write("OPENAI_API_KEY=your_openai_api_key_here\n")
            f.write("\n# Flask Configuration\n")
            f.write("FLASK_ENV=development\n")
            f.write("FLASK_DEBUG=True\n")
            f.write("\n# Dashboard Configuration\n")
            f.write("DASHBOARD_HOST=0.0.0.0\n")
            f.write("DASHBOARD_PORT=5000\n")
        logger.info(".env file created successfully")

def main():
    """Main startup function"""
    print("=" * 60)
    print("🤖 AI Dashboard - Comprehensive Analysis System")
    print("=" * 60)
    
    # Check current directory
    current_dir = Path.cwd()
    logger.info(f"Working directory: {current_dir}")
    
    # Check if we're in the right directory
    if not Path('ai_dashboard.py').exists():
        logger.error("ai_dashboard.py not found in current directory")
        logger.info("Please run this script from the AI Dashboard directory")
        return False
    
    # Check dependencies
    logger.info("Checking dependencies...")
    if not check_dependencies():
        return False
    
    # Check spaCy model
    logger.info("Checking spaCy model...")
    spacy_available = check_spacy_model()
    
    # Create .env file if needed
    create_env_file()
    
    # Import and start dashboard
    try:
        logger.info("Starting AI Dashboard...")
        from ai_dashboard import AIDashboard
        
        # Initialize dashboard
        dashboard = AIDashboard(str(current_dir))
        
        # Initialize Q&A system with empty data (will be populated when files are scanned)
        dashboard.qa_system = dashboard.qa_system.__class__({})
        
        print("\n" + "=" * 60)
        print("🚀 AI Dashboard is starting...")
        print("📊 Access the dashboard at: http://localhost:5000")
        print("🔧 Press Ctrl+C to stop the server")
        print("=" * 60)
        
        # Run the dashboard
        dashboard.run(host='0.0.0.0', port=5000, debug=True)
        
    except KeyboardInterrupt:
        logger.info("Dashboard stopped by user")
    except Exception as e:
        logger.error(f"Error starting dashboard: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1) 