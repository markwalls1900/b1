#!/usr/bin/env python3
"""
Simple HTTP Server for BWGA Nexus Regional Investment Dashboard
"""

import http.server
import socketserver
import webbrowser
import threading
import time
import os

PORT = 8080

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

def open_browser():
    """Open browser after a short delay"""
    time.sleep(2)
    webbrowser.open(f'http://localhost:{PORT}')

def main():
    print("🌍 BWGA Nexus Regional Investment Intelligence Platform")
    print("=" * 60)
    print(f"Starting local server on port {PORT}...")
    print(f"Dashboard will be available at: http://localhost:{PORT}")
    print("=" * 60)
    
    # Change to the directory containing the HTML file
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Start server
    with socketserver.TCPServer(("", PORT), CustomHandler) as httpd:
        print(f"✅ Server running at http://localhost:{PORT}")
        print("🌐 Opening dashboard in your browser...")
        print("Press Ctrl+C to stop the server")
        print("-" * 60)
        
        # Open browser in background thread
        threading.Thread(target=open_browser, daemon=True).start()
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n🛑 Server stopped by user")
            httpd.shutdown()

if __name__ == "__main__":
    main() 