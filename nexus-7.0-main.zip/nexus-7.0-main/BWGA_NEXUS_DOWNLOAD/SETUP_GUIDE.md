# 🚀 Setup Guide - Global Investment Intelligence Dashboard Backend

## Prerequisites Installation

### 1. Install Python
1. Go to https://www.python.org/downloads/
2. Download Python 3.8 or higher for Windows
3. **IMPORTANT**: Check "Add Python to PATH" during installation
4. Verify installation by opening a new terminal and running:
   ```bash
   python --version
   ```

### 2. Install Dependencies
Once Python is installed, run these commands in your terminal:

```bash
# Navigate to your project directory
cd "C:\Users\brayd\Downloads\Canva AI - Canva_files"

# Install required packages
python -m pip install fastapi uvicorn requests python-dotenv pydantic aiohttp

# Or install all dependencies at once
python -m pip install -r requirements_backend.txt
```

## 🚀 Starting the Backend

### Option 1: Using the Batch File (Easiest)
1. Double-click `start_backend.bat` in your project folder
2. The script will automatically install dependencies and start the server

### Option 2: Manual Start
```bash
# Navigate to backend directory
cd backend

# Start the server
python start_backend.py
```

### Option 3: Direct FastAPI Start
```bash
# Navigate to backend directory
cd backend

# Start with uvicorn directly
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## 🌐 Accessing the System

Once the server is running, you'll see output like:
```
🚀 Starting Global Investment Intelligence Dashboard Backend...
============================================================
📊 API Documentation: http://localhost:8000/docs
🌐 Dashboard: http://localhost:8000
🔍 Health Check: http://localhost:8000/api/health
```

### Access Points:
- **🌐 Main Dashboard**: http://localhost:8000
- **📊 API Documentation**: http://localhost:8000/docs
- **🔍 Health Check**: http://localhost:8000/api/health

## 🧪 Testing the System

### 1. Health Check
Open your browser and go to: http://localhost:8000/api/health
You should see:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-XX...",
  "version": "1.0.0",
  "services": {
    "data_service": "active",
    "ai_service": "active",
    "report_service": "active",
    "risk_service": "active"
  }
}
```

### 2. Dashboard Interface
Open http://localhost:8000 to see the interactive dashboard with:
- System status
- Global statistics
- Quick API test buttons
- Available endpoints list

### 3. API Documentation
Open http://localhost:8000/docs to see the interactive Swagger documentation where you can:
- View all available endpoints
- Test API calls directly
- See request/response schemas

## 📊 Sample API Calls

### Get Countries
```bash
curl http://localhost:8000/api/countries
```

### Get US Economic Data
```bash
curl http://localhost:8000/api/economic-data/US
```

### Analyze a Region
```bash
curl -X POST http://localhost:8000/api/analyze-region \
  -H "Content-Type: application/json" \
  -d '{
    "country_code": "US",
    "region_name": "California",
    "industry": "Technology"
  }'
```

### Generate a Report
```bash
curl -X POST http://localhost:8000/api/generate-report \
  -H "Content-Type: application/json" \
  -d '{
    "country_code": "US",
    "region_name": "California",
    "industry": "Technology",
    "requirements": ["market_analysis", "risk_assessment", "financial_projections"],
    "client_type": "company"
  }'
```

## 🔧 Troubleshooting

### Python Not Found
- Make sure Python is installed and added to PATH
- Try running `python --version` in a new terminal
- If using Windows Store Python, try `python3` instead

### Port Already in Use
If you get "port already in use" error:
```bash
# Find what's using port 8000
netstat -ano | findstr :8000

# Kill the process (replace XXXX with the PID)
taskkill /PID XXXX /F

# Or use a different port
uvicorn main:app --port 8001
```

### Missing Dependencies
If you get import errors:
```bash
# Reinstall dependencies
python -m pip install --upgrade -r requirements_backend.txt
```

### Permission Errors
- Run terminal as Administrator
- Check if antivirus is blocking the application

## 📁 Project Structure

```
Canva AI - Canva_files/
├── backend/
│   ├── main.py                 # FastAPI application
│   ├── models/schemas.py       # Data models
│   ├── services/               # Business logic
│   │   ├── data_service.py     # Data fetching
│   │   ├── ai_service.py       # AI analysis
│   │   ├── risk_service.py     # Risk assessment
│   │   └── report_service.py   # Report generation
│   ├── utils/config.py         # Configuration
│   ├── static/dashboard.html   # Web interface
│   └── start_backend.py        # Startup script
├── requirements_backend.txt    # Dependencies
├── start_backend.bat          # Windows startup script
└── README_BACKEND.md          # Detailed documentation
```

## 🎯 What You'll See

### Dashboard Features:
- ✅ Real-time system status
- 📊 Global investment statistics
- 🌍 Country and region data
- 📈 Economic indicators
- 🎯 Risk assessments
- 💰 Report generation with tiered pricing
- 🤖 AI-powered insights and forecasts

### API Capabilities:
- **8 Countries**: US, UK, Germany, Japan, China, India, Brazil, Australia
- **6 Industries**: Technology, Finance, Manufacturing, Healthcare, Energy, Retail
- **4 Report Tiers**: Basic ($99), Advanced ($299), Premium ($599), Enterprise ($1,999)
- **Real-time Analysis**: Economic data, risk assessment, growth forecasting
- **Value Calculation**: ROI potential, risk-adjusted value, competitive advantages

## 🚀 Next Steps

Once the backend is running successfully:

1. **Explore the Dashboard**: Test all the quick action buttons
2. **Check API Documentation**: Try the interactive endpoints
3. **Generate Reports**: Test the tiered report generation
4. **Analyze Regions**: Get investment insights for different areas
5. **Review the Code**: Understand the architecture and services

The system is now ready for:
- Real data integration (World Bank, Google APIs)
- Advanced ML models
- Production deployment
- Frontend development
- Database integration

## 📞 Support

If you encounter any issues:
1. Check the health endpoint: http://localhost:8000/api/health
2. Review the API documentation: http://localhost:8000/docs
3. Check the console output for error messages
4. Verify Python and dependencies are properly installed

**The backend is now fully functional and ready for development!** 🎉 