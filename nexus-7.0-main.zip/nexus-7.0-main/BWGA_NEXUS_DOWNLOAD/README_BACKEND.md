# 🌍 Global Investment Intelligence Dashboard - Backend

A comprehensive FastAPI backend for real-time investment analysis, forecasting, and risk assessment.

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip

### Installation & Running

#### Option 1: Using the batch file (Windows)
```bash
# Simply double-click or run:
start_backend.bat
```

#### Option 2: Manual setup
```bash
# 1. Install dependencies
pip install -r requirements_backend.txt

# 2. Navigate to backend directory
cd backend

# 3. Start the server
python start_backend.py
```

### Access Points
- **Dashboard**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/api/health

## 📊 Features

### Core Services
- **Data Service**: Real-time data fetching from World Bank, Google, and government APIs
- **AI Service**: Forecasting, analysis, and AI insights generation
- **Risk Service**: Comprehensive risk assessment and analysis
- **Report Service**: Tiered report generation with value calculation

### API Endpoints

#### Data & Analysis
- `GET /api/countries` - List available countries
- `GET /api/regions/{country_code}` - Get regions for a country
- `GET /api/economic-data/{country_code}` - Economic indicators
- `GET /api/industries` - List available industries
- `GET /api/dashboard-stats` - Dashboard statistics

#### Investment Analysis
- `POST /api/analyze-region` - Analyze investment opportunities
- `GET /api/forecast/{country_code}` - Growth forecasts
- `GET /api/risks/{country_code}` - Risk assessment

#### Report Generation
- `POST /api/generate-report` - Generate comprehensive reports
- `POST /api/calculate-report-value` - Calculate report value and pricing

## 🏗️ Architecture

```
backend/
├── main.py                 # FastAPI application entry point
├── models/
│   └── schemas.py         # Pydantic models and schemas
├── services/
│   ├── data_service.py    # Data fetching and management
│   ├── ai_service.py      # AI analysis and forecasting
│   ├── risk_service.py    # Risk assessment
│   └── report_service.py  # Report generation and pricing
├── utils/
│   └── config.py          # Configuration settings
├── static/
│   └── dashboard.html     # Web dashboard interface
└── start_backend.py       # Startup script
```

## 📈 Report Tiers

| Tier | Price | Value Multiplier | Features |
|------|-------|------------------|----------|
| Basic | $99 | 1.0x | Executive summary, basic analysis |
| Advanced | $299 | 2.5x | + Financial projections, recommendations |
| Premium | $599 | 5.0x | + Competitive analysis, regulatory compliance |
| Enterprise | $1,999 | 15.0x | + Detailed financial model, stakeholder analysis |

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the backend directory:

```env
# API Keys (optional for demo)
WORLD_BANK_API_KEY=your_world_bank_key
GOOGLE_API_KEY=your_google_key
OPENWEATHER_API_KEY=your_weather_key

# Server Configuration
HOST=0.0.0.0
PORT=8000
DEBUG=True

# Security
SECRET_KEY=your-secret-key-here
```

## 🧪 Testing the API

### Using the Dashboard
1. Open http://localhost:8000
2. Click the "Quick Actions" buttons to test endpoints
3. View real-time API responses

### Using curl
```bash
# Health check
curl http://localhost:8000/api/health

# Get countries
curl http://localhost:8000/api/countries

# Get US economic data
curl http://localhost:8000/api/economic-data/US

# Analyze a region
curl -X POST http://localhost:8000/api/analyze-region \
  -H "Content-Type: application/json" \
  -d '{"country_code": "US", "region_name": "California", "industry": "Technology"}'
```

### Using the API Documentation
1. Open http://localhost:8000/docs
2. Explore all available endpoints
3. Test endpoints directly from the browser

## 📊 Sample Data

The system includes realistic sample data for:
- **8 Countries**: US, UK, Germany, Japan, China, India, Brazil, Australia
- **6 Industries**: Technology, Finance, Manufacturing, Healthcare, Energy, Retail
- **Economic Indicators**: GDP growth, inflation, unemployment, foreign investment
- **Risk Assessments**: Political, economic, environmental, infrastructure, regulatory risks

## 🔮 Next Steps

### Phase 1: Real Data Integration
- [ ] Integrate World Bank API for real economic data
- [ ] Add Google Trends API for market sentiment
- [ ] Implement government data APIs
- [ ] Add real-time news and social media sentiment

### Phase 2: Advanced Features
- [ ] Machine learning models for forecasting
- [ ] Real-time data streaming
- [ ] Advanced risk modeling
- [ ] Portfolio optimization algorithms

### Phase 3: Production Features
- [ ] User authentication and authorization
- [ ] Database integration (PostgreSQL)
- [ ] Redis caching
- [ ] Celery for background tasks
- [ ] Docker containerization

## 🛠️ Development

### Adding New Endpoints
1. Add the endpoint to `main.py`
2. Create corresponding service methods
3. Update schemas if needed
4. Test via the dashboard or API docs

### Adding New Data Sources
1. Extend `DataService` class
2. Add API key to configuration
3. Implement data fetching methods
4. Update sample data if needed

## 📝 License

This project is part of the BWGA Nexus Core Final system.

## 🤝 Support

For questions or issues:
1. Check the API documentation at http://localhost:8000/docs
2. Review the health check at http://localhost:8000/api/health
3. Test individual endpoints using the dashboard interface 