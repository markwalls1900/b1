"""
Production Configuration for BWGA Nexus Investment Intelligence Platform
"""

import os
from typing import List
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "BWGA Nexus Investment Intelligence"
    VERSION: str = "7.1.0"
    DEBUG: bool = Field(default=False, env="DEBUG")
    
    # Server
    HOST: str = Field(default="0.0.0.0", env="HOST")
    PORT: int = Field(default=8000, env="PORT")
    
    # Database
    DATABASE_URL: str = Field(
        default="postgresql://user:password@localhost/bwga_nexus",
        env="DATABASE_URL"
    )
    
    # Redis
    REDIS_URL: str = Field(
        default="redis://localhost:6379",
        env="REDIS_URL"
    )
    
    # Security
    SECRET_KEY: str = Field(
        default="your-super-secret-key-change-in-production",
        env="SECRET_KEY"
    )
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # External APIs
    ALPHA_VANTAGE_API_KEY: str = Field(default="", env="ALPHA_VANTAGE_API_KEY")
    FRED_API_KEY: str = Field(default="", env="FRED_API_KEY")
    WORLD_BANK_API_KEY: str = Field(default="", env="WORLD_BANK_API_KEY")
    TWITTER_API_KEY: str = Field(default="", env="TWITTER_API_KEY")
    TWITTER_API_SECRET: str = Field(default="", env="TWITTER_API_SECRET")
    TWITTER_ACCESS_TOKEN: str = Field(default="", env="TWITTER_ACCESS_TOKEN")
    TWITTER_ACCESS_SECRET: str = Field(default="", env="TWITTER_ACCESS_SECRET")
    
    # Payment Processing
    STRIPE_SECRET_KEY: str = Field(default="", env="STRIPE_SECRET_KEY")
    STRIPE_PUBLISHABLE_KEY: str = Field(default="", env="STRIPE_PUBLISHABLE_KEY")
    
    # Email
    SENDGRID_API_KEY: str = Field(default="", env="SENDGRID_API_KEY")
    FROM_EMAIL: str = Field(default="noreply@bwganexus.com", env="FROM_EMAIL")
    
    # AI/ML
    OPENAI_API_KEY: str = Field(default="", env="OPENAI_API_KEY")
    HUGGINGFACE_API_KEY: str = Field(default="", env="HUGGINGFACE_API_KEY")
    
    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8000",
        "https://bwganexus.com",
        "https://app.bwganexus.com"
    ]
    
    # Subscription Tiers
    SUBSCRIPTION_TIERS = {
        "basic": {
            "price": 99,
            "features": ["basic_analysis", "standard_reports", "email_support"],
            "api_calls_per_month": 1000,
            "reports_per_month": 5
        },
        "professional": {
            "price": 299,
            "features": ["advanced_analysis", "premium_reports", "priority_support", "api_access"],
            "api_calls_per_month": 10000,
            "reports_per_month": 25
        },
        "enterprise": {
            "price": 999,
            "features": ["ai_forecasting", "custom_reports", "dedicated_support", "white_label"],
            "api_calls_per_month": 100000,
            "reports_per_month": 100
        }
    }
    
    # Data Sources
    DATA_SOURCES = {
        "financial": ["yfinance", "alpha_vantage", "fred"],
        "economic": ["world_bank", "imf", "oecd"],
        "news": ["newsapi", "twitter", "reddit"],
        "social": ["twitter", "reddit", "stocktwits"]
    }
    
    # AI Models
    AI_MODELS = {
        "forecasting": "prophet",
        "sentiment": "bert",
        "classification": "xgboost",
        "regression": "random_forest"
    }
    
    class Config:
        env_file = ".env"

settings = Settings() 