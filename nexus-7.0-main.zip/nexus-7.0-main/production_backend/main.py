#!/usr/bin/env python3
"""
BWGA Nexus - Production Investment Intelligence Platform
Real-time data integration, AI analysis, and professional reporting
"""

from fastapi import FastAPI, HTTPException, Depends, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import uvicorn
import os
import asyncio
from datetime import datetime, timedelta
import json
from typing import List, Optional, Dict, Any
import logging

# Import our production modules
from core.config import settings
from core.database import engine, SessionLocal
from core.security import get_current_user, create_access_token
from models.user import User
from models.investment import Investment, Report, Subscription
from services.data_service import DataService
from services.ai_service import AIService
from services.report_service import ReportService
from services.risk_service import RiskService
from services.payment_service import PaymentService
from services.notification_service import NotificationService
from api.v1.endpoints import auth, investments, reports, analytics, admin
from core.celery_app import celery_app

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="BWGA Nexus Investment Intelligence Platform",
    description="Production-grade investment analysis, AI forecasting, and risk assessment",
    version="7.1.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()

# Initialize services
data_service = DataService()
ai_service = AIService()
report_service = ReportService()
risk_service = RiskService()
payment_service = PaymentService()
notification_service = NotificationService()

# Include API routers
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(investments.router, prefix="/api/v1/investments", tags=["Investments"])
app.include_router(reports.router, prefix="/api/v1/reports", tags=["Reports"])
app.include_router(analytics.router, prefix="/api/v1/analytics", tags=["Analytics"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin"])

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main dashboard"""
    try:
        with open("static/dashboard.html", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(content="""
        <html>
            <head><title>BWGA Nexus Investment Intelligence</title></head>
            <body>
                <h1>🌍 BWGA Nexus Investment Intelligence Platform</h1>
                <p>Production system is running successfully!</p>
                <p><a href="/api/docs">View API Documentation</a></p>
                <p><a href="/api/v1/health">Health Check</a></p>
            </body>
        </html>
        """)

@app.get("/api/v1/health")
async def health_check():
    """Comprehensive health check"""
    try:
        # Check database connection
        db = SessionLocal()
        db.execute("SELECT 1")
        db.close()
        
        # Check Redis connection
        redis_status = await data_service.check_redis_connection()
        
        # Check external APIs
        api_status = await data_service.check_external_apis()
        
        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "version": "7.1.0",
            "services": {
                "database": "connected",
                "redis": redis_status,
                "external_apis": api_status,
                "ai_models": "loaded",
                "payment_processor": "active"
            },
            "uptime": "running"
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        raise HTTPException(status_code=503, detail="Service unavailable")

@app.get("/api/v1/market-data/global")
async def get_global_market_data():
    """Get real-time global market data"""
    try:
        data = await data_service.get_global_market_data()
        return {"success": True, "data": data}
    except Exception as e:
        logger.error(f"Failed to fetch global market data: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/analyze/investment")
async def analyze_investment(
    background_tasks: BackgroundTasks,
    analysis_request: dict,
    current_user: User = Depends(get_current_user)
):
    """Perform comprehensive investment analysis"""
    try:
        # Start background analysis task
        task = celery_app.send_task(
            "tasks.analyze_investment",
            args=[analysis_request, current_user.id]
        )
        
        return {
            "success": True,
            "task_id": task.id,
            "message": "Analysis started. Check status with task_id."
        }
    except Exception as e:
        logger.error(f"Investment analysis failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/analysis/status/{task_id}")
async def get_analysis_status(task_id: str):
    """Get analysis task status"""
    try:
        task_result = celery_app.AsyncResult(task_id)
        return {
            "task_id": task_id,
            "status": task_result.status,
            "result": task_result.result if task_result.ready() else None
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/reports/generate")
async def generate_professional_report(
    report_request: dict,
    current_user: User = Depends(get_current_user)
):
    """Generate professional investment report"""
    try:
        # Check subscription tier
        subscription = await payment_service.get_user_subscription(current_user.id)
        if not subscription or subscription.status != "active":
            raise HTTPException(status_code=403, detail="Active subscription required")
        
        # Generate report
        report = await report_service.generate_professional_report(
            report_request, current_user, subscription.tier
        )
        
        # Send notification
        await notification_service.send_report_notification(current_user, report)
        
        return {"success": True, "report": report}
    except Exception as e:
        logger.error(f"Report generation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/forecast/ai/{country_code}")
async def get_ai_forecast(
    country_code: str,
    industry: Optional[str] = None,
    timeframe: str = "5y"
):
    """Get AI-powered investment forecast"""
    try:
        forecast = await ai_service.generate_forecast(country_code, industry, timeframe)
        return {"success": True, "forecast": forecast}
    except Exception as e:
        logger.error(f"AI forecast failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/subscriptions/create")
async def create_subscription(
    subscription_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create new subscription"""
    try:
        subscription = await payment_service.create_subscription(
            current_user, subscription_data
        )
        return {"success": True, "subscription": subscription}
    except Exception as e:
        logger.error(f"Subscription creation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/dashboard/analytics")
async def get_dashboard_analytics(
    current_user: User = Depends(get_current_user)
):
    """Get personalized dashboard analytics"""
    try:
        analytics = await data_service.get_user_analytics(current_user.id)
        return {"success": True, "analytics": analytics}
    except Exception as e:
        logger.error(f"Dashboard analytics failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/ws/market-updates")
async def websocket_market_updates(websocket):
    """Real-time market updates via WebSocket"""
    try:
        await websocket.accept()
        while True:
            # Send real-time market data
            market_data = await data_service.get_realtime_market_data()
            await websocket.send_text(json.dumps(market_data))
            await asyncio.sleep(30)  # Update every 30 seconds
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
    finally:
        await websocket.close()

if __name__ == "__main__":
    logger.info("Starting BWGA Nexus Investment Intelligence Platform...")
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info"
    ) 