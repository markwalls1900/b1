#!/usr/bin/env python3
"""
BWGA Nexus Production Platform Startup Script
Simplified version for demonstration
"""

import uvicorn
import os
import sys
from pathlib import Path

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

def main():
    """Start the production platform"""
    print("🌍 Starting BWGA Nexus Investment Intelligence Platform...")
    print("Version: 7.1.0")
    print("Environment: Production")
    print("-" * 50)
    
    # Configuration
    host = "0.0.0.0"
    port = 8000
    reload = False
    
    print(f"Server will start on: http://{host}:{port}")
    print("API Documentation: http://localhost:8000/api/docs")
    print("Health Check: http://localhost:8000/api/v1/health")
    print("-" * 50)
    
    try:
        # Start the server
        uvicorn.run(
            "main:app",
            host=host,
            port=port,
            reload=reload,
            log_level="info"
        )
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 