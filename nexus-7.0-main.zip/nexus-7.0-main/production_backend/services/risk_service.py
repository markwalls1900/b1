"""
Risk Service - Investment risk assessment and management
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)

class RiskService:
    def __init__(self):
        self.risk_models = {
            "var": self._calculate_var,
            "cvar": self._calculate_cvar,
            "volatility": self._calculate_volatility,
            "beta": self._calculate_beta,
            "sharpe": self._calculate_sharpe_ratio,
            "max_drawdown": self._calculate_max_drawdown
        }

    async def calculate_risk_metrics(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive risk metrics"""
        try:
            # Extract price data
            price_history = market_data.get("historical_data", [])
            if not price_history:
                return self._get_default_risk_metrics()
            
            # Convert to pandas DataFrame
            df = pd.DataFrame(price_history)
            if 'Close' in df.columns:
                prices = df['Close'].values
            else:
                prices = df.iloc[:, -1].values  # Assume last column is price
            
            # Calculate returns
            returns = np.diff(prices) / prices[:-1]
            
            # Calculate risk metrics
            risk_metrics = {
                "volatility": self._calculate_volatility(returns),
                "var_95": self._calculate_var(returns, 0.05),
                "cvar_95": self._calculate_cvar(returns, 0.05),
                "var_99": self._calculate_var(returns, 0.01),
                "cvar_99": self._calculate_cvar(returns, 0.01),
                "max_drawdown": self._calculate_max_drawdown(prices),
                "sharpe_ratio": self._calculate_sharpe_ratio(returns),
                "sortino_ratio": self._calculate_sortino_ratio(returns),
                "calmar_ratio": self._calculate_calmar_ratio(returns, prices),
                "beta": self._calculate_beta(returns),
                "skewness": self._calculate_skewness(returns),
                "kurtosis": self._calculate_kurtosis(returns)
            }
            
            return risk_metrics
            
        except Exception as e:
            logger.error(f"Risk metrics calculation failed: {str(e)}")
            return self._get_default_risk_metrics()

    async def generate_risk_assessment(self, market_data: Dict[str, Any], risk_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Generate comprehensive risk assessment"""
        try:
            # Risk level classification
            risk_level = self._classify_risk_level(risk_metrics)
            
            # Risk factors analysis
            risk_factors = self._analyze_risk_factors(risk_metrics, market_data)
            
            # Stress testing scenarios
            stress_scenarios = self._generate_stress_scenarios(risk_metrics)
            
            # Risk mitigation recommendations
            mitigation_strategies = self._generate_mitigation_strategies(risk_level, risk_factors)
            
            return {
                "risk_level": risk_level,
                "risk_factors": risk_factors,
                "stress_scenarios": stress_scenarios,
                "mitigation_strategies": mitigation_strategies,
                "risk_score": self._calculate_risk_score(risk_metrics),
                "assessment_date": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Risk assessment generation failed: {str(e)}")
            raise

    def _calculate_var(self, returns: np.ndarray, confidence_level: float) -> float:
        """Calculate Value at Risk"""
        try:
            return np.percentile(returns, confidence_level * 100)
        except Exception:
            return -0.02

    def _calculate_cvar(self, returns: np.ndarray, confidence_level: float) -> float:
        """Calculate Conditional Value at Risk (Expected Shortfall)"""
        try:
            var = self._calculate_var(returns, confidence_level)
            return np.mean(returns[returns <= var])
        except Exception:
            return -0.025

    def _calculate_volatility(self, returns: np.ndarray) -> float:
        """Calculate annualized volatility"""
        try:
            return np.std(returns) * np.sqrt(252)  # Annualized
        except Exception:
            return 0.15

    def _calculate_beta(self, returns: np.ndarray) -> float:
        """Calculate beta relative to market"""
        try:
            # Mock market returns (in real implementation, use actual market data)
            market_returns = np.random.normal(0.0005, 0.015, len(returns))
            covariance = np.cov(returns, market_returns)[0, 1]
            market_variance = np.var(market_returns)
            return covariance / market_variance if market_variance > 0 else 1.0
        except Exception:
            return 1.0

    def _calculate_sharpe_ratio(self, returns: np.ndarray) -> float:
        """Calculate Sharpe ratio"""
        try:
            risk_free_rate = 0.02  # 2% annual risk-free rate
            excess_returns = returns - risk_free_rate / 252
            return np.mean(excess_returns) / np.std(returns) if np.std(returns) > 0 else 0
        except Exception:
            return 0.5

    def _calculate_sortino_ratio(self, returns: np.ndarray) -> float:
        """Calculate Sortino ratio"""
        try:
            risk_free_rate = 0.02  # 2% annual risk-free rate
            excess_returns = returns - risk_free_rate / 252
            downside_returns = excess_returns[excess_returns < 0]
            downside_deviation = np.std(downside_returns) if len(downside_returns) > 0 else 0.01
            return np.mean(excess_returns) / downside_deviation if downside_deviation > 0 else 0
        except Exception:
            return 0.3

    def _calculate_calmar_ratio(self, returns: np.ndarray, prices: np.ndarray) -> float:
        """Calculate Calmar ratio"""
        try:
            max_drawdown = self._calculate_max_drawdown(prices)
            annual_return = np.mean(returns) * 252
            return annual_return / abs(max_drawdown) if max_drawdown != 0 else 0
        except Exception:
            return 0.2

    def _calculate_max_drawdown(self, prices: np.ndarray) -> float:
        """Calculate maximum drawdown"""
        try:
            peak = prices[0]
            max_dd = 0
            
            for price in prices:
                if price > peak:
                    peak = price
                drawdown = (peak - price) / peak
                max_dd = max(max_dd, drawdown)
            
            return max_dd
        except Exception:
            return 0.15

    def _calculate_skewness(self, returns: np.ndarray) -> float:
        """Calculate skewness"""
        try:
            return float(pd.Series(returns).skew())
        except Exception:
            return 0.0

    def _calculate_kurtosis(self, returns: np.ndarray) -> float:
        """Calculate kurtosis"""
        try:
            return float(pd.Series(returns).kurtosis())
        except Exception:
            return 3.0

    def _classify_risk_level(self, risk_metrics: Dict[str, float]) -> str:
        """Classify overall risk level"""
        risk_score = 0
        
        # Volatility contribution
        volatility = risk_metrics.get("volatility", 0.15)
        if volatility > 0.25:
            risk_score += 3
        elif volatility > 0.15:
            risk_score += 2
        else:
            risk_score += 1
        
        # VaR contribution
        var_95 = abs(risk_metrics.get("var_95", -0.02))
        if var_95 > 0.05:
            risk_score += 3
        elif var_95 > 0.03:
            risk_score += 2
        else:
            risk_score += 1
        
        # Max drawdown contribution
        max_dd = risk_metrics.get("max_drawdown", 0.15)
        if max_dd > 0.25:
            risk_score += 3
        elif max_dd > 0.15:
            risk_score += 2
        else:
            risk_score += 1
        
        # Beta contribution
        beta = risk_metrics.get("beta", 1.0)
        if beta > 1.5:
            risk_score += 2
        elif beta > 1.0:
            risk_score += 1
        else:
            risk_score += 0
        
        if risk_score >= 8:
            return "HIGH"
        elif risk_score >= 5:
            return "MEDIUM"
        else:
            return "LOW"

    def _analyze_risk_factors(self, risk_metrics: Dict[str, float], market_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Analyze specific risk factors"""
        risk_factors = []
        
        # Market risk
        volatility = risk_metrics.get("volatility", 0.15)
        if volatility > 0.20:
            risk_factors.append({
                "factor": "Market Volatility",
                "level": "HIGH" if volatility > 0.25 else "MEDIUM",
                "description": f"High volatility ({volatility:.2%}) indicates significant price fluctuations",
                "impact": "High price swings may lead to significant losses"
            })
        
        # Liquidity risk
        volume = market_data.get("volume", 0)
        if volume < 1000000:  # Less than 1M shares
            risk_factors.append({
                "factor": "Liquidity Risk",
                "level": "HIGH",
                "description": "Low trading volume may limit ability to enter/exit positions",
                "impact": "Difficulty in executing trades at desired prices"
            })
        
        # Concentration risk
        sector = market_data.get("sector", "")
        if sector in ["Technology", "Healthcare"]:
            risk_factors.append({
                "factor": "Sector Concentration",
                "level": "MEDIUM",
                "description": f"Concentration in {sector} sector increases sector-specific risk",
                "impact": "Vulnerable to sector-wide downturns"
            })
        
        return risk_factors

    def _generate_stress_scenarios(self, risk_metrics: Dict[str, float]) -> List[Dict[str, Any]]:
        """Generate stress testing scenarios"""
        scenarios = [
            {
                "scenario": "Market Crash",
                "description": "Simulation of 2008-style market crash",
                "impact": "Potential 40-60% portfolio decline",
                "probability": "Low (5-10%)",
                "mitigation": "Diversification, defensive positioning"
            },
            {
                "scenario": "Interest Rate Shock",
                "description": "Rapid increase in interest rates",
                "impact": "Bond prices decline, growth stocks underperform",
                "probability": "Medium (15-25%)",
                "mitigation": "Duration management, floating rate exposure"
            },
            {
                "scenario": "Sector Rotation",
                "description": "Shift from growth to value stocks",
                "impact": "Technology/growth stocks decline 20-30%",
                "probability": "Medium (20-30%)",
                "mitigation": "Balanced growth/value allocation"
            }
        ]
        
        return scenarios

    def _generate_mitigation_strategies(self, risk_level: str, risk_factors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate risk mitigation strategies"""
        strategies = []
        
        if risk_level == "HIGH":
            strategies.extend([
                {
                    "strategy": "Position Sizing",
                    "description": "Reduce position size to limit exposure",
                    "implementation": "Limit single position to 2-3% of portfolio"
                },
                {
                    "strategy": "Stop-Loss Orders",
                    "description": "Implement automatic stop-loss orders",
                    "implementation": "Set stop-loss at 15-20% below entry price"
                }
            ])
        
        if risk_level in ["MEDIUM", "HIGH"]:
            strategies.extend([
                {
                    "strategy": "Diversification",
                    "description": "Increase portfolio diversification",
                    "implementation": "Spread investments across sectors and asset classes"
                },
                {
                    "strategy": "Regular Rebalancing",
                    "description": "Maintain target asset allocation",
                    "implementation": "Rebalance portfolio quarterly"
                }
            ])
        
        return strategies

    def _calculate_risk_score(self, risk_metrics: Dict[str, float]) -> float:
        """Calculate overall risk score (0-100)"""
        try:
            # Weighted risk score calculation
            weights = {
                "volatility": 0.25,
                "var_95": 0.20,
                "max_drawdown": 0.20,
                "beta": 0.15,
                "skewness": 0.10,
                "kurtosis": 0.10
            }
            
            score = 0
            for metric, weight in weights.items():
                if metric in risk_metrics:
                    # Normalize each metric to 0-100 scale
                    if metric == "volatility":
                        normalized = min(100, risk_metrics[metric] * 400)  # 25% = 100
                    elif metric == "var_95":
                        normalized = min(100, abs(risk_metrics[metric]) * 2000)  # 5% = 100
                    elif metric == "max_drawdown":
                        normalized = min(100, risk_metrics[metric] * 400)  # 25% = 100
                    elif metric == "beta":
                        normalized = min(100, risk_metrics[metric] * 50)  # Beta 2 = 100
                    else:
                        normalized = 50  # Default
                    
                    score += normalized * weight
            
            return min(100, max(0, score))
            
        except Exception:
            return 50.0

    def _get_default_risk_metrics(self) -> Dict[str, float]:
        """Get default risk metrics when calculation fails"""
        return {
            "volatility": 0.15,
            "var_95": -0.02,
            "cvar_95": -0.025,
            "var_99": -0.03,
            "cvar_99": -0.035,
            "max_drawdown": 0.15,
            "sharpe_ratio": 0.5,
            "sortino_ratio": 0.3,
            "calmar_ratio": 0.2,
            "beta": 1.0,
            "skewness": 0.0,
            "kurtosis": 3.0
        } 