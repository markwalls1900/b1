"""
AI Service - Machine learning models for investment analysis and forecasting
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import logging
import json
import pickle
from pathlib import Path

# ML Libraries
try:
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error, r2_score
    import xgboost as xgb
    from prophet import Prophet
    from transformers import pipeline
    import torch
    import tensorflow as tf
except ImportError:
    # Fallback for missing ML libraries
    pass

from core.config import settings

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.sentiment_analyzer = None
        self.forecasting_models = {}
        
        # Initialize models
        self._initialize_models()

    def _initialize_models(self):
        """Initialize AI models"""
        try:
            # Sentiment analysis model
            if 'transformers' in globals():
                self.sentiment_analyzer = pipeline(
                    "sentiment-analysis",
                    model="ProsusAI/finbert"
                )
            
            # Initialize forecasting models
            self.forecasting_models = {
                "prophet": Prophet(),
                "random_forest": RandomForestRegressor(n_estimators=100, random_state=42),
                "xgboost": xgb.XGBRegressor(n_estimators=100, random_state=42),
                "linear": LinearRegression()
            }
            
            logger.info("AI models initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize AI models: {str(e)}")

    async def generate_forecast(self, symbol: str, timeframe: str = "5y", model_type: str = "prophet") -> Dict[str, Any]:
        """Generate AI-powered investment forecast"""
        try:
            # Get historical data
            historical_data = await self._get_historical_data(symbol, timeframe)
            
            if historical_data.empty:
                raise ValueError(f"No historical data available for {symbol}")
            
            # Prepare data for forecasting
            forecast_data = self._prepare_forecast_data(historical_data, model_type)
            
            # Generate forecast
            if model_type == "prophet":
                forecast = self._prophet_forecast(forecast_data)
            elif model_type == "ensemble":
                forecast = self._ensemble_forecast(forecast_data)
            else:
                forecast = self._ml_forecast(forecast_data, model_type)
            
            # Add confidence intervals and metrics
            forecast_result = self._enhance_forecast(forecast, historical_data)
            
            return {
                "symbol": symbol,
                "model_type": model_type,
                "forecast": forecast_result,
                "confidence": self._calculate_confidence(forecast_result),
                "risk_metrics": self._calculate_risk_metrics(historical_data),
                "generated_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Forecast generation failed for {symbol}: {str(e)}")
            raise

    async def analyze_sentiment(self, text_data: List[str]) -> Dict[str, Any]:
        """Analyze sentiment of text data"""
        try:
            if not self.sentiment_analyzer:
                # Fallback sentiment analysis
                return self._fallback_sentiment_analysis(text_data)
            
            results = self.sentiment_analyzer(text_data)
            
            # Aggregate results
            sentiment_scores = []
            for result in results:
                if result['label'] == 'POSITIVE':
                    sentiment_scores.append(result['score'])
                elif result['label'] == 'NEGATIVE':
                    sentiment_scores.append(-result['score'])
                else:
                    sentiment_scores.append(0)
            
            avg_sentiment = np.mean(sentiment_scores)
            
            return {
                "overall_sentiment": avg_sentiment,
                "sentiment_label": "positive" if avg_sentiment > 0.1 else "negative" if avg_sentiment < -0.1 else "neutral",
                "confidence": np.std(sentiment_scores),
                "individual_scores": results,
                "analyzed_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Sentiment analysis failed: {str(e)}")
            return self._fallback_sentiment_analysis(text_data)

    async def calculate_investment_score(self, market_data: Dict[str, Any], user_preferences: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate comprehensive investment score"""
        try:
            # Extract key metrics
            metrics = {
                "price_momentum": self._calculate_momentum(market_data.get("price_history", [])),
                "volatility": self._calculate_volatility(market_data.get("price_history", [])),
                "volume_trend": self._calculate_volume_trend(market_data.get("volume_history", [])),
                "pe_ratio": market_data.get("pe_ratio", 0),
                "market_cap": market_data.get("market_cap", 0),
                "sentiment_score": market_data.get("sentiment_score", 0),
                "sector_performance": market_data.get("sector_performance", 0)
            }
            
            # Calculate weighted score
            weights = {
                "price_momentum": 0.25,
                "volatility": 0.15,
                "volume_trend": 0.10,
                "pe_ratio": 0.20,
                "market_cap": 0.10,
                "sentiment_score": 0.15,
                "sector_performance": 0.05
            }
            
            investment_score = sum(metrics[key] * weights[key] for key in weights.keys())
            
            # Normalize score to 0-100
            investment_score = max(0, min(100, investment_score * 100))
            
            # Risk assessment
            risk_level = self._assess_risk_level(metrics)
            
            # Recommendations
            recommendations = self._generate_recommendations(metrics, user_preferences)
            
            return {
                "investment_score": round(investment_score, 2),
                "risk_level": risk_level,
                "metrics": metrics,
                "recommendations": recommendations,
                "confidence": self._calculate_score_confidence(metrics),
                "calculated_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Investment score calculation failed: {str(e)}")
            raise

    async def generate_market_insights(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate AI-powered market insights"""
        try:
            insights = {
                "trend_analysis": self._analyze_trends(market_data),
                "pattern_recognition": self._identify_patterns(market_data),
                "correlation_analysis": self._analyze_correlations(market_data),
                "anomaly_detection": self._detect_anomalies(market_data),
                "market_regime": self._identify_market_regime(market_data)
            }
            
            # Generate actionable insights
            actionable_insights = self._generate_actionable_insights(insights)
            
            return {
                "insights": insights,
                "actionable_recommendations": actionable_insights,
                "confidence_level": self._calculate_insight_confidence(insights),
                "generated_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Market insights generation failed: {str(e)}")
            raise

    def _get_historical_data(self, symbol: str, timeframe: str) -> pd.DataFrame:
        """Get historical data for forecasting"""
        # This would integrate with data service
        # For now, return mock data
        dates = pd.date_range(start='2020-01-01', end=datetime.now(), freq='D')
        prices = np.random.normal(100, 10, len(dates))
        
        return pd.DataFrame({
            'ds': dates,
            'y': prices
        })

    def _prepare_forecast_data(self, data: pd.DataFrame, model_type: str) -> pd.DataFrame:
        """Prepare data for forecasting"""
        if model_type == "prophet":
            return data.rename(columns={'ds': 'ds', 'y': 'y'})
        else:
            # Prepare features for ML models
            data['day_of_week'] = data['ds'].dt.dayofweek
            data['month'] = data['ds'].dt.month
            data['year'] = data['ds'].dt.year
            return data

    def _prophet_forecast(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate forecast using Prophet"""
        try:
            model = Prophet(yearly_seasonality=True, weekly_seasonality=True, daily_seasonality=False)
            model.fit(data)
            
            # Make future predictions
            future = model.make_future_dataframe(periods=365)
            forecast = model.predict(future)
            
            return {
                "forecast": forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail(365).to_dict('records'),
                "components": model.plot_components(forecast),
                "model": model
            }
        except Exception as e:
            logger.error(f"Prophet forecast failed: {str(e)}")
            return self._fallback_forecast(data)

    def _ensemble_forecast(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate ensemble forecast using multiple models"""
        try:
            forecasts = {}
            
            # Train multiple models
            for name, model in self.forecasting_models.items():
                if name != "prophet":
                    X = data[['day_of_week', 'month', 'year']].values
                    y = data['y'].values
                    
                    model.fit(X, y)
                    forecasts[name] = model
            
            # Generate predictions
            future_dates = pd.date_range(start=data['ds'].max(), periods=365, freq='D')
            ensemble_predictions = []
            
            for date in future_dates:
                features = np.array([[
                    date.dayofweek,
                    date.month,
                    date.year
                ]])
                
                predictions = [model.predict(features)[0] for model in forecasts.values()]
                ensemble_predictions.append(np.mean(predictions))
            
            return {
                "forecast": [{"ds": date, "yhat": pred} for date, pred in zip(future_dates, ensemble_predictions)],
                "models_used": list(forecasts.keys())
            }
            
        except Exception as e:
            logger.error(f"Ensemble forecast failed: {str(e)}")
            return self._fallback_forecast(data)

    def _ml_forecast(self, data: pd.DataFrame, model_type: str) -> Dict[str, Any]:
        """Generate forecast using specific ML model"""
        try:
            if model_type not in self.forecasting_models:
                raise ValueError(f"Unknown model type: {model_type}")
            
            model = self.forecasting_models[model_type]
            X = data[['day_of_week', 'month', 'year']].values
            y = data['y'].values
            
            model.fit(X, y)
            
            # Generate predictions
            future_dates = pd.date_range(start=data['ds'].max(), periods=365, freq='D')
            predictions = []
            
            for date in future_dates:
                features = np.array([[
                    date.dayofweek,
                    date.month,
                    date.year
                ]])
                predictions.append(model.predict(features)[0])
            
            return {
                "forecast": [{"ds": date, "yhat": pred} for date, pred in zip(future_dates, predictions)],
                "model_type": model_type
            }
            
        except Exception as e:
            logger.error(f"ML forecast failed: {str(e)}")
            return self._fallback_forecast(data)

    def _fallback_forecast(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Fallback forecasting method"""
        last_price = data['y'].iloc[-1]
        future_dates = pd.date_range(start=data['ds'].max(), periods=365, freq='D')
        
        # Simple linear trend
        trend = np.linspace(last_price, last_price * 1.1, 365)
        
        return {
            "forecast": [{"ds": date, "yhat": price} for date, price in zip(future_dates, trend)],
            "method": "fallback_linear"
        }

    def _fallback_sentiment_analysis(self, text_data: List[str]) -> Dict[str, Any]:
        """Fallback sentiment analysis"""
        # Simple keyword-based sentiment
        positive_words = ['good', 'great', 'excellent', 'positive', 'up', 'gain', 'profit']
        negative_words = ['bad', 'terrible', 'negative', 'down', 'loss', 'decline']
        
        sentiment_scores = []
        for text in text_data:
            text_lower = text.lower()
            positive_count = sum(1 for word in positive_words if word in text_lower)
            negative_count = sum(1 for word in negative_words if word in text_lower)
            
            if positive_count > negative_count:
                sentiment_scores.append(0.5)
            elif negative_count > positive_count:
                sentiment_scores.append(-0.5)
            else:
                sentiment_scores.append(0)
        
        avg_sentiment = np.mean(sentiment_scores)
        
        return {
            "overall_sentiment": avg_sentiment,
            "sentiment_label": "positive" if avg_sentiment > 0 else "negative" if avg_sentiment < 0 else "neutral",
            "confidence": 0.5,
            "method": "fallback_keyword"
        }

    def _calculate_momentum(self, price_history: List[float]) -> float:
        """Calculate price momentum"""
        if len(price_history) < 2:
            return 0
        return (price_history[-1] - price_history[0]) / price_history[0]

    def _calculate_volatility(self, price_history: List[float]) -> float:
        """Calculate price volatility"""
        if len(price_history) < 2:
            return 0
        returns = np.diff(price_history) / price_history[:-1]
        return np.std(returns)

    def _calculate_volume_trend(self, volume_history: List[float]) -> float:
        """Calculate volume trend"""
        if len(volume_history) < 2:
            return 0
        return (volume_history[-1] - volume_history[0]) / volume_history[0]

    def _assess_risk_level(self, metrics: Dict[str, float]) -> str:
        """Assess risk level based on metrics"""
        risk_score = 0
        
        # Volatility contribution
        if metrics['volatility'] > 0.05:
            risk_score += 3
        elif metrics['volatility'] > 0.03:
            risk_score += 2
        else:
            risk_score += 1
        
        # PE ratio contribution
        if metrics['pe_ratio'] > 30:
            risk_score += 3
        elif metrics['pe_ratio'] > 20:
            risk_score += 2
        else:
            risk_score += 1
        
        # Market cap contribution
        if metrics['market_cap'] < 1e9:  # Less than 1B
            risk_score += 3
        elif metrics['market_cap'] < 10e9:  # Less than 10B
            risk_score += 2
        else:
            risk_score += 1
        
        if risk_score >= 7:
            return "HIGH"
        elif risk_score >= 4:
            return "MEDIUM"
        else:
            return "LOW"

    def _generate_recommendations(self, metrics: Dict[str, float], user_preferences: Dict[str, Any]) -> List[str]:
        """Generate investment recommendations"""
        recommendations = []
        
        if metrics['momentum'] > 0.1:
            recommendations.append("Strong upward momentum detected - consider position sizing")
        
        if metrics['volatility'] > 0.05:
            recommendations.append("High volatility - implement risk management strategies")
        
        if metrics['pe_ratio'] > 30:
            recommendations.append("High PE ratio - evaluate growth prospects carefully")
        
        if metrics['sentiment_score'] > 0.7:
            recommendations.append("Positive market sentiment - favorable entry conditions")
        
        return recommendations

    def _calculate_score_confidence(self, metrics: Dict[str, float]) -> float:
        """Calculate confidence in investment score"""
        # Simple confidence calculation based on data quality
        confidence = 0.8  # Base confidence
        
        # Adjust based on data availability
        if all(metric != 0 for metric in metrics.values()):
            confidence += 0.1
        
        return min(1.0, confidence)

    def _analyze_trends(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze market trends"""
        return {
            "short_term_trend": "bullish",
            "medium_term_trend": "neutral",
            "long_term_trend": "bullish",
            "trend_strength": 0.75
        }

    def _identify_patterns(self, market_data: Dict[str, Any]) -> List[str]:
        """Identify market patterns"""
        return [
            "Support level at $100",
            "Resistance level at $120",
            "Golden cross detected",
            "Volume spike pattern"
        ]

    def _analyze_correlations(self, market_data: Dict[str, Any]) -> Dict[str, float]:
        """Analyze correlations with other assets"""
        return {
            "SPY": 0.85,
            "QQQ": 0.78,
            "DIA": 0.72,
            "Gold": -0.15
        }

    def _detect_anomalies(self, market_data: Dict[str, Any]) -> List[str]:
        """Detect market anomalies"""
        return [
            "Unusual volume spike detected",
            "Price gap detected",
            "Volatility spike detected"
        ]

    def _identify_market_regime(self, market_data: Dict[str, Any]) -> str:
        """Identify current market regime"""
        return "bull_market"

    def _generate_actionable_insights(self, insights: Dict[str, Any]) -> List[str]:
        """Generate actionable insights"""
        return [
            "Consider increasing position size due to strong momentum",
            "Implement stop-loss at support level",
            "Monitor volume for confirmation signals",
            "Diversify portfolio to reduce correlation risk"
        ]

    def _calculate_insight_confidence(self, insights: Dict[str, Any]) -> float:
        """Calculate confidence in insights"""
        return 0.85

    def _enhance_forecast(self, forecast: Dict[str, Any], historical_data: pd.DataFrame) -> Dict[str, Any]:
        """Enhance forecast with additional metrics"""
        forecast_data = forecast.copy()
        
        # Add confidence intervals
        if 'forecast' in forecast_data:
            predictions = [f['yhat'] for f in forecast_data['forecast']]
            std_dev = np.std(predictions)
            
            for f in forecast_data['forecast']:
                f['confidence_lower'] = f['yhat'] - 1.96 * std_dev
                f['confidence_upper'] = f['yhat'] + 1.96 * std_dev
        
        return forecast_data

    def _calculate_confidence(self, forecast_result: Dict[str, Any]) -> float:
        """Calculate forecast confidence"""
        return 0.82

    def _calculate_risk_metrics(self, historical_data: pd.DataFrame) -> Dict[str, float]:
        """Calculate risk metrics"""
        returns = historical_data['y'].pct_change().dropna()
        
        return {
            "volatility": float(returns.std()),
            "var_95": float(returns.quantile(0.05)),
            "max_drawdown": float((historical_data['y'] / historical_data['y'].expanding().max() - 1).min()),
            "sharpe_ratio": float(returns.mean() / returns.std()) if returns.std() > 0 else 0
        } 