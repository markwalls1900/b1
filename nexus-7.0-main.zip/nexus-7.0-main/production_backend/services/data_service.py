"""
Production Data Service - Real-time data integration from multiple sources
"""

import asyncio
import aiohttp
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import redis
import json
import logging
from fredapi import Fred
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.fundamentaldata import FundamentalData
import requests

from core.config import settings

logger = logging.getLogger(__name__)

class DataService:
    def __init__(self):
        self.session = None
        self.redis_client = redis.from_url(settings.REDIS_URL)
        self.fred = Fred(api_key=settings.FRED_API_KEY)
        self.alpha_vantage = TimeSeries(key=settings.ALPHA_VANTAGE_API_KEY)
        self.fundamental_data = FundamentalData(key=settings.ALPHA_VANTAGE_API_KEY)
        
        # Cache configuration
        self.cache_duration = {
            "market_data": 300,  # 5 minutes
            "economic_data": 3600,  # 1 hour
            "news_data": 1800,  # 30 minutes
            "social_data": 900,  # 15 minutes
        }

    async def get_session(self):
        """Get or create aiohttp session"""
        if self.session is None:
            self.session = aiohttp.ClientSession()
        return self.session

    async def get_global_market_data(self) -> Dict[str, Any]:
        """Get real-time global market data"""
        cache_key = "global_market_data"
        cached_data = self.redis_client.get(cache_key)
        
        if cached_data:
            return json.loads(cached_data)
        
        try:
            # Major indices
            indices = {
                "SPY": "S&P 500",
                "QQQ": "NASDAQ",
                "DIA": "Dow Jones",
                "IWM": "Russell 2000",
                "EFA": "MSCI EAFE",
                "EEM": "MSCI Emerging Markets"
            }
            
            market_data = {}
            for symbol, name in indices.items():
                try:
                    ticker = yf.Ticker(symbol)
                    info = ticker.info
                    hist = ticker.history(period="1d")
                    
                    if not hist.empty:
                        market_data[name] = {
                            "symbol": symbol,
                            "price": float(hist['Close'].iloc[-1]),
                            "change": float(hist['Close'].iloc[-1] - hist['Open'].iloc[0]),
                            "change_percent": float((hist['Close'].iloc[-1] - hist['Open'].iloc[0]) / hist['Open'].iloc[0] * 100),
                            "volume": int(hist['Volume'].iloc[-1]),
                            "market_cap": info.get('marketCap', 0),
                            "timestamp": datetime.now().isoformat()
                        }
                except Exception as e:
                    logger.error(f"Error fetching {symbol}: {str(e)}")
                    continue
            
            # Economic indicators
            economic_data = await self.get_economic_indicators()
            market_data["economic_indicators"] = economic_data
            
            # Cache the data
            self.redis_client.setex(
                cache_key, 
                self.cache_duration["market_data"], 
                json.dumps(market_data)
            )
            
            return market_data
            
        except Exception as e:
            logger.error(f"Failed to fetch global market data: {str(e)}")
            raise

    async def get_economic_indicators(self) -> Dict[str, Any]:
        """Get key economic indicators"""
        try:
            indicators = {
                "GDP": "GDP",  # Real GDP
                "UNRATE": "Unemployment Rate",
                "CPIAUCSL": "Inflation (CPI)",
                "FEDFUNDS": "Federal Funds Rate",
                "DGS10": "10-Year Treasury Yield",
                "DGS2": "2-Year Treasury Yield",
                "DEXUSEU": "USD/EUR Exchange Rate",
                "DEXCHUS": "USD/CNY Exchange Rate"
            }
            
            economic_data = {}
            for fred_code, name in indicators.items():
                try:
                    data = self.fred.get_series(fred_code, limit=1)
                    if not data.empty:
                        economic_data[name] = {
                            "value": float(data.iloc[-1]),
                            "date": data.index[-1].strftime("%Y-%m-%d"),
                            "code": fred_code
                        }
                except Exception as e:
                    logger.error(f"Error fetching {fred_code}: {str(e)}")
                    continue
            
            return economic_data
            
        except Exception as e:
            logger.error(f"Failed to fetch economic indicators: {str(e)}")
            return {}

    async def get_stock_data(self, symbol: str, period: str = "1y") -> Dict[str, Any]:
        """Get comprehensive stock data"""
        try:
            ticker = yf.Ticker(symbol)
            
            # Historical data
            hist = ticker.history(period=period)
            
            # Company info
            info = ticker.info
            
            # Financial statements
            financials = ticker.financials
            balance_sheet = ticker.balance_sheet
            cashflow = ticker.cashflow
            
            # Analyst recommendations
            recommendations = ticker.recommendations
            
            # Options data
            options = ticker.options
            
            stock_data = {
                "symbol": symbol,
                "company_name": info.get('longName', ''),
                "sector": info.get('sector', ''),
                "industry": info.get('industry', ''),
                "market_cap": info.get('marketCap', 0),
                "pe_ratio": info.get('trailingPE', 0),
                "price": float(hist['Close'].iloc[-1]) if not hist.empty else 0,
                "historical_data": hist.to_dict('records') if not hist.empty else [],
                "financials": financials.to_dict() if not financials.empty else {},
                "balance_sheet": balance_sheet.to_dict() if not balance_sheet.empty else {},
                "cashflow": cashflow.to_dict() if not cashflow.empty else {},
                "recommendations": recommendations.to_dict('records') if not recommendations.empty else [],
                "options": options,
                "timestamp": datetime.now().isoformat()
            }
            
            return stock_data
            
        except Exception as e:
            logger.error(f"Failed to fetch stock data for {symbol}: {str(e)}")
            raise

    async def get_news_sentiment(self, query: str, days: int = 7) -> Dict[str, Any]:
        """Get news sentiment analysis"""
        try:
            # This would integrate with news APIs like NewsAPI, Twitter, etc.
            # For now, returning mock data structure
            news_data = {
                "query": query,
                "total_articles": 150,
                "sentiment_score": 0.65,
                "sentiment_label": "positive",
                "top_headlines": [
                    {
                        "title": f"Positive news about {query}",
                        "sentiment": "positive",
                        "confidence": 0.85,
                        "source": "Reuters",
                        "published_at": datetime.now().isoformat()
                    }
                ],
                "sentiment_breakdown": {
                    "positive": 65,
                    "neutral": 25,
                    "negative": 10
                },
                "timestamp": datetime.now().isoformat()
            }
            
            return news_data
            
        except Exception as e:
            logger.error(f"Failed to fetch news sentiment: {str(e)}")
            raise

    async def get_social_sentiment(self, symbol: str) -> Dict[str, Any]:
        """Get social media sentiment"""
        try:
            # This would integrate with Twitter, Reddit, StockTwits APIs
            # For now, returning mock data structure
            social_data = {
                "symbol": symbol,
                "platforms": {
                    "twitter": {
                        "mentions": 1250,
                        "sentiment_score": 0.72,
                        "trending": True
                    },
                    "reddit": {
                        "mentions": 890,
                        "sentiment_score": 0.68,
                        "trending": False
                    },
                    "stocktwits": {
                        "mentions": 567,
                        "sentiment_score": 0.75,
                        "trending": True
                    }
                },
                "overall_sentiment": 0.72,
                "sentiment_label": "positive",
                "timestamp": datetime.now().isoformat()
            }
            
            return social_data
            
        except Exception as e:
            logger.error(f"Failed to fetch social sentiment: {str(e)}")
            raise

    async def get_realtime_market_data(self) -> Dict[str, Any]:
        """Get real-time market data for WebSocket"""
        try:
            # Get current market data
            market_data = await self.get_global_market_data()
            
            # Add real-time indicators
            realtime_data = {
                "market_data": market_data,
                "timestamp": datetime.now().isoformat(),
                "market_status": "open" if self.is_market_open() else "closed"
            }
            
            return realtime_data
            
        except Exception as e:
            logger.error(f"Failed to fetch real-time data: {str(e)}")
            return {"error": str(e)}

    def is_market_open(self) -> bool:
        """Check if US market is open"""
        now = datetime.now()
        # Simple check - in production, use proper market hours
        return 9 <= now.hour < 16 and now.weekday() < 5

    async def check_redis_connection(self) -> str:
        """Check Redis connection status"""
        try:
            self.redis_client.ping()
            return "connected"
        except Exception as e:
            logger.error(f"Redis connection failed: {str(e)}")
            return "disconnected"

    async def check_external_apis(self) -> Dict[str, str]:
        """Check external API connections"""
        status = {}
        
        # Check Alpha Vantage
        try:
            data, meta_data = self.alpha_vantage.get_intraday('AAPL', interval='1min', outputsize='compact')
            status["alpha_vantage"] = "connected"
        except Exception as e:
            status["alpha_vantage"] = "disconnected"
        
        # Check FRED
        try:
            self.fred.get_series('GDP', limit=1)
            status["fred"] = "connected"
        except Exception as e:
            status["fred"] = "disconnected"
        
        # Check Yahoo Finance
        try:
            yf.Ticker("AAPL").info
            status["yfinance"] = "connected"
        except Exception as e:
            status["yfinance"] = "disconnected"
        
        return status

    async def get_user_analytics(self, user_id: int) -> Dict[str, Any]:
        """Get personalized analytics for user"""
        try:
            # This would fetch user-specific data from database
            analytics = {
                "user_id": user_id,
                "portfolio_value": 125000,
                "total_investments": 15,
                "reports_generated": 23,
                "favorite_sectors": ["Technology", "Healthcare", "Finance"],
                "risk_tolerance": "moderate",
                "performance_metrics": {
                    "total_return": 12.5,
                    "volatility": 8.2,
                    "sharpe_ratio": 1.8
                },
                "recent_activities": [
                    {"action": "Generated Report", "timestamp": datetime.now().isoformat()},
                    {"action": "Analyzed Stock", "timestamp": datetime.now().isoformat()}
                ]
            }
            
            return analytics
            
        except Exception as e:
            logger.error(f"Failed to fetch user analytics: {str(e)}")
            raise

    async def close(self):
        """Close the session"""
        if self.session:
            await self.session.close() 