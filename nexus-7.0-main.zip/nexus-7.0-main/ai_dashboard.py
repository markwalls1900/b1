#!/usr/bin/env python3
"""
Comprehensive AI Dashboard System
Processes binary files, generates AI reports, and provides interactive Q&A
"""

import os
import base64
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional
import asyncio
import aiofiles
from pathlib import Path
import logging

# Web framework imports
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_socketio import SocketIO, emit
import threading

# AI and ML imports
import openai
from transformers import pipeline, AutoTokenizer, AutoModel
import torch
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import spacy

# Data processing
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FileProcessor:
    """Handles binary file processing and analysis"""
    
    def __init__(self, workspace_path: str):
        self.workspace_path = Path(workspace_path)
        self.processed_files = {}
        self.file_metadata = {}
        
    async def scan_files(self) -> Dict[str, Any]:
        """Scan and categorize all files in workspace"""
        files_info = {
            'html': [],
            'css': [],
            'javascript': [],
            'binary': [],
            'base64': []
        }
        
        for file_path in self.workspace_path.rglob('*'):
            if file_path.is_file():
                file_info = {
                    'name': file_path.name,
                    'path': str(file_path),
                    'size': file_path.stat().st_size,
                    'modified': datetime.fromtimestamp(file_path.stat().st_mtime)
                }
                
                if file_path.suffix == '.html':
                    files_info['html'].append(file_info)
                elif file_path.suffix == '.css' or 'css' in file_path.name:
                    files_info['css'].append(file_info)
                elif file_path.suffix == '.js' or 'js' in file_path.name:
                    files_info['javascript'].append(file_info)
                elif file_path.suffix == '.base64':
                    files_info['base64'].append(file_info)
                else:
                    files_info['binary'].append(file_info)
        
        return files_info
    
    async def decode_base64_file(self, file_path: str) -> str:
        """Decode base64 file back to original content"""
        try:
            async with aiofiles.open(file_path, 'r') as f:
                content = await f.read()
            return base64.b64decode(content).decode('utf-8', errors='ignore')
        except Exception as e:
            logger.error(f"Error decoding {file_path}: {e}")
            return ""
    
    async def extract_text_content(self, file_path: str) -> str:
        """Extract text content from various file types"""
        try:
            if file_path.endswith('.base64'):
                return await self.decode_base64_file(file_path)
            else:
                async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return await f.read()
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return ""

class AIAnalyzer:
    """AI-powered content analysis and report generation"""
    
    def __init__(self):
        self.nlp = None
        self.sentiment_analyzer = None
        self.text_classifier = None
        self.initialize_models()
    
    def initialize_models(self):
        """Initialize AI models for analysis"""
        try:
            # Initialize sentiment analysis
            self.sentiment_analyzer = pipeline("sentiment-analysis")
            
            # Initialize text classification
            self.text_classifier = pipeline("text-classification")
            
            # Load spaCy for NLP
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except:
                logger.warning("spaCy model not found, using basic text processing")
                self.nlp = None
                
        except Exception as e:
            logger.error(f"Error initializing AI models: {e}")
    
    def analyze_content(self, content: str) -> Dict[str, Any]:
        """Comprehensive content analysis"""
        analysis = {
            'length': len(content),
            'word_count': len(content.split()),
            'sentiment': None,
            'topics': [],
            'entities': [],
            'summary': '',
            'keywords': [],
            'complexity_score': 0
        }
        
        if not content.strip():
            return analysis
        
        try:
            # Sentiment analysis
            if self.sentiment_analyzer:
                sentiment_result = self.sentiment_analyzer(content[:1000])[0]
                analysis['sentiment'] = {
                    'label': sentiment_result['label'],
                    'score': sentiment_result['score']
                }
            
            # Topic extraction using TF-IDF
            words = content.lower().split()
            if len(words) > 10:
                analysis['keywords'] = self.extract_keywords(content)
            
            # Entity extraction
            if self.nlp:
                doc = self.nlp(content[:2000])
                analysis['entities'] = [ent.text for ent in doc.ents[:10]]
            
            # Complexity score
            analysis['complexity_score'] = self.calculate_complexity(content)
            
        except Exception as e:
            logger.error(f"Error in content analysis: {e}")
        
        return analysis
    
    def extract_keywords(self, text: str, top_k: int = 10) -> List[str]:
        """Extract keywords using TF-IDF"""
        try:
            words = text.lower().split()
            if len(words) < 5:
                return []
            
            # Simple keyword extraction
            word_freq = {}
            for word in words:
                if len(word) > 3 and word.isalpha():
                    word_freq[word] = word_freq.get(word, 0) + 1
            
            sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            return [word for word, freq in sorted_words[:top_k]]
        except:
            return []
    
    def calculate_complexity(self, text: str) -> float:
        """Calculate text complexity score"""
        try:
            words = text.split()
            if not words:
                return 0
            
            avg_word_length = sum(len(word) for word in words) / len(words)
            unique_words = len(set(words))
            lexical_diversity = unique_words / len(words)
            
            return (avg_word_length * 0.4 + lexical_diversity * 0.6) * 10
        except:
            return 0
    
    def generate_summary(self, content: str, max_length: int = 200) -> str:
        """Generate content summary"""
        try:
            sentences = content.split('.')
            if len(sentences) <= 2:
                return content[:max_length]
            
            # Simple extractive summarization
            summary_sentences = sentences[:3]
            summary = '. '.join(summary_sentences) + '.'
            
            if len(summary) > max_length:
                summary = summary[:max_length-3] + '...'
            
            return summary
        except:
            return content[:max_length]

class ReportGenerator:
    """Generates comprehensive reports from analyzed data"""
    
    def __init__(self):
        self.report_templates = self.load_report_templates()
    
    def load_report_templates(self) -> Dict[str, str]:
        """Load report templates"""
        return {
            'executive_summary': """
# Executive Summary Report

## Overview
- Total Files Analyzed: {total_files}
- Total Content Size: {total_size} bytes
- Analysis Date: {date}

## Key Findings
{key_findings}

## Recommendations
{recommendations}
            """,
            
            'technical_analysis': """
# Technical Analysis Report

## File Structure
{file_structure}

## Content Analysis
{content_analysis}

## AI Insights
{ai_insights}
            """,
            
            'interactive_qa': """
# Interactive Q&A Report

## Common Questions
{common_questions}

## Answer Patterns
{answer_patterns}

## Suggested Improvements
{improvements}
            """
        }
    
    def generate_executive_summary(self, analysis_data: Dict[str, Any]) -> str:
        """Generate executive summary report"""
        total_files = len(analysis_data.get('files', []))
        total_size = sum(f.get('size', 0) for f in analysis_data.get('files', []))
        
        key_findings = []
        for file_info in analysis_data.get('files', [])[:5]:
            if file_info.get('analysis'):
                findings = f"- {file_info['name']}: {file_info['analysis'].get('sentiment', {}).get('label', 'Neutral')} sentiment"
                key_findings.append(findings)
        
        recommendations = [
            "- Consider content optimization for better engagement",
            "- Implement regular content audits",
            "- Focus on high-performing content types"
        ]
        
        return self.report_templates['executive_summary'].format(
            total_files=total_files,
            total_size=total_size,
            date=datetime.now().strftime("%Y-%m-%d"),
            key_findings='\n'.join(key_findings),
            recommendations='\n'.join(recommendations)
        )
    
    def generate_technical_report(self, analysis_data: Dict[str, Any]) -> str:
        """Generate technical analysis report"""
        file_structure = []
        for file_info in analysis_data.get('files', []):
            structure = f"- {file_info['name']} ({file_info.get('size', 0)} bytes)"
            file_structure.append(structure)
        
        content_analysis = []
        for file_info in analysis_data.get('files', [])[:10]:
            if file_info.get('analysis'):
                analysis = file_info['analysis']
                content_info = f"- {file_info['name']}: {analysis.get('word_count', 0)} words, complexity: {analysis.get('complexity_score', 0):.1f}"
                content_analysis.append(content_info)
        
        return self.report_templates['technical_analysis'].format(
            file_structure='\n'.join(file_structure),
            content_analysis='\n'.join(content_analysis),
            ai_insights="AI analysis completed successfully"
        )

class QASystem:
    """Interactive Q&A system for client interactions"""
    
    def __init__(self, analysis_data: Dict[str, Any]):
        self.analysis_data = analysis_data
        self.qa_history = []
        self.common_questions = self.generate_common_questions()
    
    def generate_common_questions(self) -> List[str]:
        """Generate common questions based on content"""
        questions = [
            "What types of files are in this workspace?",
            "What is the overall sentiment of the content?",
            "What are the main topics covered?",
            "How complex is the content?",
            "What are the key insights from the analysis?",
            "How can I optimize this content?",
            "What are the technical specifications?",
            "What recommendations do you have?"
        ]
        return questions
    
    def answer_question(self, question: str) -> Dict[str, Any]:
        """Answer client questions based on analysis data"""
        question_lower = question.lower()
        answer = {
            'question': question,
            'answer': '',
            'confidence': 0.8,
            'sources': [],
            'timestamp': datetime.now().isoformat()
        }
        
        # File types question
        if 'file' in question_lower and 'type' in question_lower:
            file_types = {}
            for file_info in self.analysis_data.get('files', []):
                ext = Path(file_info['name']).suffix
                file_types[ext] = file_types.get(ext, 0) + 1
            
            answer['answer'] = f"The workspace contains: {', '.join([f'{count} {ext} files' for ext, count in file_types.items()])}"
        
        # Sentiment question
        elif 'sentiment' in question_lower:
            sentiments = []
            for file_info in self.analysis_data.get('files', [])[:10]:
                if file_info.get('analysis', {}).get('sentiment'):
                    sentiments.append(file_info['analysis']['sentiment']['label'])
            
            if sentiments:
                most_common = max(set(sentiments), key=sentiments.count)
                answer['answer'] = f"The overall sentiment is predominantly {most_common}"
            else:
                answer['answer'] = "Sentiment analysis is not available for the current content"
        
        # Topics question
        elif 'topic' in question_lower:
            all_keywords = []
            for file_info in self.analysis_data.get('files', [])[:10]:
                keywords = file_info.get('analysis', {}).get('keywords', [])
                all_keywords.extend(keywords)
            
            if all_keywords:
                top_keywords = list(set(all_keywords))[:10]
                answer['answer'] = f"Main topics include: {', '.join(top_keywords)}"
            else:
                answer['answer'] = "Topic analysis is not available for the current content"
        
        # Complexity question
        elif 'complex' in question_lower:
            complexities = []
            for file_info in self.analysis_data.get('files', [])[:10]:
                complexity = file_info.get('analysis', {}).get('complexity_score', 0)
                complexities.append(complexity)
            
            if complexities:
                avg_complexity = sum(complexities) / len(complexities)
                complexity_level = "low" if avg_complexity < 3 else "medium" if avg_complexity < 6 else "high"
                answer['answer'] = f"The content complexity is {complexity_level} (average score: {avg_complexity:.1f})"
            else:
                answer['answer'] = "Complexity analysis is not available"
        
        # Default answer
        else:
            answer['answer'] = "I can help you with questions about file types, sentiment analysis, topics, complexity, and recommendations. Please ask a specific question."
            answer['confidence'] = 0.5
        
        self.qa_history.append(answer)
        return answer
    
    def get_qa_history(self) -> List[Dict[str, Any]]:
        """Get Q&A history"""
        return self.qa_history

class AIDashboard:
    """Main AI Dashboard application"""
    
    def __init__(self, workspace_path: str):
        self.workspace_path = workspace_path
        self.file_processor = FileProcessor(workspace_path)
        self.ai_analyzer = AIAnalyzer()
        self.report_generator = ReportGenerator()
        self.qa_system = None
        self.analysis_data = {}
        
        # Flask app setup
        self.app = Flask(__name__)
        self.app.secret_key = 'ai_dashboard_secret_key_2024'
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        
        self.setup_routes()
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            return render_template('dashboard.html')
        
        @self.app.route('/api/scan', methods=['POST'])
        def scan_files():
            """Scan and analyze files"""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                files_info = loop.run_until_complete(self.file_processor.scan_files())
                loop.close()
                
                return jsonify({'success': True, 'files': files_info})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        
        @self.app.route('/api/analyze', methods=['POST'])
        def analyze_content():
            """Analyze content using AI"""
            try:
                data = request.json
                file_path = data.get('file_path')
                
                if not file_path:
                    return jsonify({'success': False, 'error': 'No file path provided'})
                
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                content = loop.run_until_complete(self.file_processor.extract_text_content(file_path))
                loop.close()
                
                analysis = self.ai_analyzer.analyze_content(content)
                
                return jsonify({
                    'success': True,
                    'analysis': analysis,
                    'content_preview': content[:500] + '...' if len(content) > 500 else content
                })
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        
        @self.app.route('/api/report/<report_type>', methods=['GET'])
        def generate_report(report_type):
            """Generate reports"""
            try:
                if report_type == 'executive':
                    report = self.report_generator.generate_executive_summary(self.analysis_data)
                elif report_type == 'technical':
                    report = self.report_generator.generate_technical_report(self.analysis_data)
                else:
                    return jsonify({'success': False, 'error': 'Invalid report type'})
                
                return jsonify({'success': True, 'report': report})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        
        @self.app.route('/api/qa/ask', methods=['POST'])
        def ask_question():
            """Handle Q&A requests"""
            try:
                data = request.json
                question = data.get('question', '')
                
                if not self.qa_system:
                    return jsonify({'success': False, 'error': 'Q&A system not initialized'})
                
                answer = self.qa_system.answer_question(question)
                return jsonify({'success': True, 'answer': answer})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
        
        @self.app.route('/api/qa/history', methods=['GET'])
        def get_qa_history():
            """Get Q&A history"""
            try:
                if not self.qa_system:
                    return jsonify({'success': False, 'error': 'Q&A system not initialized'})
                
                history = self.qa_system.get_qa_history()
                return jsonify({'success': True, 'history': history})
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)})
    
    def run(self, host='0.0.0.0', port=5000, debug=True):
        """Run the dashboard"""
        logger.info(f"Starting AI Dashboard on http://{host}:{port}")
        self.socketio.run(self.app, host=host, port=port, debug=debug)

if __name__ == "__main__":
    # Initialize dashboard
    workspace_path = os.getcwd()
    dashboard = AIDashboard(workspace_path)
    
    # Run the application
    dashboard.run() 