
import { GoogleGenAI } from "@google/genai";

// --- State and Configuration ---
let userProfile = {};
let generatedReport = {};
let activeView = 'welcome';
let isLoading = false;

// This is a placeholder for the API key. In a real-world scenario,
// this should be managed securely and not hardcoded.
const API_KEY = process.env.API_KEY;
let ai;

if (!API_KEY) {
  console.warn("API_KEY is not set. The application will use fallback data.");
} else {
  try {
    ai = new GoogleGenAI({apiKey: API_KEY});
  } catch (e) {
    console.error("Failed to initialize GoogleGenAI:", e);
    ai = null; // Ensure ai is null if initialization fails
  }
}

// --- Data for Forms ---
const countries = ["USA", "China", "Japan", "Germany", "UK", "India", "France", "Italy", "Canada", "South Korea", "Russia", "Australia", "Brazil", "Spain", "Mexico", "Indonesia", "Netherlands", "Saudi Arabia", "Switzerland", "Turkey", "Taiwan", "Sweden", "Poland", "Belgium", "Thailand", "Ireland", "Austria", "Norway", "Israel", "Argentina", "Nigeria", "South Africa", "Denmark", "United Arab Emirates", "Egypt", "Malaysia", "Singapore", "Philippines", "Vietnam", "Colombia", "Chile", "Finland", "Bangladesh", "Romania", "Czech Republic", "Portugal", "Greece", "New Zealand", "Peru", "Qatar", "Iraq", "Hungary", "Algeria", "Kazakhstan", "Kuwait"];
const industries = ["Technology", "Healthcare", "Financials", "Consumer Discretionary", "Communication Services", "Industrials", "Consumer Staples", "Energy", "Utilities", "Real Estate", "Materials", "Agriculture", "Manufacturing", "Logistics", "Tourism", "Mining"];


// --- HTML Templates & SVGs ---
const ICONS = {
    builder: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2.15l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2.15l.15-.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path><circle cx="12" cy="12" r="3"></circle></svg>`,
    map: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`,
};

const templates = {
    shell: `
        <div class="flex h-screen bg-slate-50 text-slate-800">
            <aside id="sidebar" class="w-64 bg-white border-r flex-shrink-0 flex-col hidden md:flex transition-all duration-300">
                <div class="flex items-center justify-center h-20 border-b px-4">
                    <h1 class="text-2xl font-bold tracking-tight text-slate-800">BWGA Nexus</h1>
                </div>
                <nav id="sidebar-nav" class="flex-1 p-4 space-y-2"></nav>
                <div class="p-4 border-t text-xs text-slate-500">
                  © ${new Date().getFullYear()} BWGA Global Advisory
                </div>
            </aside>
            <main id="main-content" class="flex-1 flex flex-col">
                <header class="flex items-center justify-between h-20 border-b bg-white/80 backdrop-blur-lg sticky top-0 px-6 z-10">
                    <h2 id="view-title" class="text-xl font-semibold text-slate-800">AI Report Builder</h2>
                    <div class="text-sm text-slate-500">Aegis v7.0</div>
                </header>
                <div id="content-area" class="flex-1 p-4 sm:p-6 md:p-10 overflow-y-auto content-bg"></div>
            </main>
        </div>`,
    welcome: `
        <div class="p-8 text-center dashboard-view animate-fadeIn">
             <h2 class="text-4xl font-bold tracking-tight text-slate-900">AI-Human Intelligence Platform</h2>
            <p class="mt-3 text-xl text-slate-600 max-w-2xl mx-auto">Select your role to begin generating a bespoke regional intelligence brief.</p>
            <div class="mt-10 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
                <div id="start-business-btn" class="p-8 border-2 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 cursor-pointer transition-all duration-300 shadow-sm hover:shadow-xl">
                    <h3 class="font-semibold text-xl text-slate-800">Business / Investor</h3>
                    <p class="mt-2 text-slate-500">Identify market expansion opportunities, optimize supply chains, and de-risk investments.</p>
                </div>
                <div id="start-government-btn" class="p-8 border-2 rounded-xl hover:border-indigo-500 hover:bg-indigo-50 cursor-pointer transition-all duration-300 shadow-sm hover:shadow-xl">
                    <h3 class="font-semibold text-xl text-slate-800">Government / Agency</h3>
                     <p class="mt-2 text-slate-500">Attract targeted FDI, formulate development policy, and build public-private partnerships.</p>
                </div>
            </div>
        </div>`,
    builderForm: (userType) => `
         <div class="p-2 sm:p-8 max-w-3xl mx-auto dashboard-view animate-fadeIn">
            <h2 class="text-2xl font-semibold mb-2 text-center">Nexus Dialogue: Build Your Report</h2>
            <p class="text-center text-slate-500 mb-8">Provide the following details to generate your tailored intelligence brief.</p>
            <div class="space-y-6 bg-white p-8 rounded-xl shadow-md border">
                <div>
                    <label for="organization" class="block mb-1 font-medium text-slate-700">Organization / Project Name</label>
                    <input type="text" id="organization" placeholder="e.g., John Deere ASEAN Expansion" class="mt-1"/>
                </div>
                 <div>
                    <label for="country" class="block mb-1 font-medium text-slate-700">Country of Interest</label>
                    <select id="country" class="mt-1">
                        <option value="">Select a country...</option>
                        ${countries.map(c => `<option value="${c}">${c}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label for="objective" class="block mb-1 font-medium text-slate-700">Primary Objective</label>
                    <select id="objective" class="mt-1">
                        <option value="">Select an objective...</option>
                        ${(userType === 'Business' 
                            ? ["Market Expansion", "Supply Chain Diversification", "Resource Sourcing", "Sustainable Investment"] 
                            : ["FDI Attraction", "Regional Economic Development", "Export Promotion", "Infrastructure Investment"]
                        ).map(o => `<option value="${o}">${o}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label for="industry" class="block mb-1 font-medium text-slate-700">Primary Industry</label>
                    <select id="industry" class="mt-1">
                        <option value="">Select an industry...</option>
                        ${industries.map(i => `<option value="${i}">${i}</option>`).join('')}
                    </select>
                </div>
                 ${userType === 'Business' ? `
                <div>
                    <label for="companySize" class="block mb-1 font-medium text-slate-700">Company Size</label>
                    <select id="companySize" class="mt-1">
                        <option value="SME (1-250 employees)">SME (1-250 employees)</option>
                        <option value="Enterprise (251-5000 employees)">Enterprise (251-5000 employees)</option>
                        <option value="Large Corporation (5000+ employees)">Large Corporation (5000+ employees)</option>
                    </select>
                </div>
                <div>
                    <label for="budget" class="block mb-1 font-medium text-slate-700">Indicative Project Budget (USD)</label>
                    <input type="number" id="budget" placeholder="e.g., 5000000" class="mt-1"/>
                </div>
                ` : `
                <div>
                    <label for="incentives" class="block mb-1 font-medium text-slate-700">Incentives Offered (Optional)</label>
                    <textarea id="incentives" rows="3" placeholder="e.g., Tax holidays, streamlined permits, dedicated industrial zone access..." class="mt-1"></textarea>
                </div>
                `}
            </div>
            <div class="flex justify-between mt-8">
                <button id="back-to-welcome-btn" class="px-6 py-2 bg-slate-200 rounded-lg hover:bg-slate-300 font-medium transition">Back</button>
                <button id="generate-brief-btn" class="px-8 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition shadow-sm hover:shadow-md">Generate Intelligence Brief</button>
            </div>
        </div>`,
    loading: `
         <div class="p-16 text-center animate-pulse dashboard-view">
            <div role="status" class="flex justify-center items-center">
                <svg aria-hidden="true" class="w-12 h-12 text-slate-200 animate-spin fill-indigo-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/><path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0492C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/></svg>
            </div>
            <h2 class="text-3xl font-semibold mt-6">NSIL™ AI Engine is Running...</h2>
            <p class="text-lg text-slate-500 mt-2">Analyzing global data streams, applying proprietary logic, and generating your strategic brief.</p>
        </div>`,
    result: `
        <div class="p-2 sm:p-8 max-w-5xl mx-auto text-center dashboard-view animate-fadeIn">
            <h2 class="text-4xl font-bold text-green-600">✔️ Intelligence Brief Ready</h2>
            <p class="mt-2 text-lg text-slate-600">Your AI-generated analysis for <strong id="result-org-name"></strong> is complete.</p>

            <div class="mt-8 p-6 bg-white border rounded-xl shadow-lg">
                <div class="grid md:grid-cols-3 gap-6 text-center">
                    <div class="p-4 rounded-lg bg-slate-50 border">
                        <p class="text-sm font-medium text-slate-500">URP Index™</p>
                        <p id="metric-urp" class="text-5xl font-bold text-indigo-600"></p>
                    </div>
                    <div class="p-4 rounded-lg bg-slate-50 border">
                        <p class="text-sm font-medium text-slate-500">AGER-AI™ Risk Score</p>
                        <p id="metric-risk" class="text-5xl font-bold text-red-600"></p>
                    </div>
                    <div class="p-4 rounded-lg bg-slate-50 border">
                        <p class="text-sm font-medium text-slate-500">Recommended Tier</p>
                        <p id="metric-tier" class="text-2xl pt-2 font-bold text-slate-800"></p>
                    </div>
                </div>

                <div id="report-summary-container" class="mt-6 pt-6 border-t text-left text-slate-800">
                    <!-- Populated by JS -->
                </div>
            </div>

            <div class="mt-10">
                <button id="download-pdf-btn" class="w-full max-w-lg px-8 py-4 bg-indigo-600 text-white rounded-lg font-semibold text-xl hover:bg-indigo-700 shadow-xl hover:shadow-2xl transition-all duration-300">
                    Download Full PDF Brief
                </button>
            </div>
            <button id="start-new-report-btn" class="mt-6 text-sm text-slate-500 hover:underline">Start a New Report</button>
        </div>`,
    map: `
        <div class="p-4 dashboard-view animate-fadeIn">
            <h2 class="text-3xl font-bold tracking-tight text-slate-900">Global Opportunity Map</h2>
            <p class="mt-2 text-slate-600">An interactive, live view of regional potential and investment activity. (Conceptual)</p>
            <div class="mt-6 bg-slate-200 rounded-lg h-96 flex items-center justify-center text-slate-500 border-dashed border-2 border-slate-300">
                Interactive Map Placeholder
            </div>
        </div>
        `,
};

// --- Core Application Logic ---

async function runNexusAiAnalysis(profile) {
    if (!ai) {
        return getFallbackAnalysis(profile);
    }

    const prompt = `
    You are an AI analyst for BWGA (Brayden Walls Global Advisory), specializing in regional economic development and investment strategy. Your language is professional, insightful, and confident, adhering to the proprietary NSIL (Nexus Symbiotic Intelligence Language) style.

    A user is exploring an investment opportunity. Based on their profile below, generate a structured JSON object containing:
    1.  'executiveSummary': A concise 150-word executive summary. It must start with "NSIL™ Analysis:" and analyze the potential, risks, and key factors for the user's stated objective in the specified country.
    2.  'urpIndex': A "Universal Regional Potential" score between 6.5 and 9.5, to one decimal place.
    3.  'riskScore': An "Advanced Governance & Economic Risk" score between 2.0 and 7.5, to one decimal place.
    4.  'partnerArchetypes': An array of 3-4 strings describing ideal partner types (e.g., "Local logistics provider with cold-chain capabilities", "Domestic construction firm with government contracts").
    5.  'recommendedTier': A recommended service tier. It MUST be one of: "Tier 1: Regional Opportunity Explorer", "Tier 2: Strategic Partnership Facilitator", or "Tier 3: Transformation Impact Simulator". Base this on the complexity implied by the user's objective and profile.
    6.  'keyOpportunities': An array of 3 strings listing key opportunities.
    7.  'keyRisks': An array of 3 strings listing key risks.
    
    User Profile:
    - User Type: ${profile.userType}
    - Organization / Project: ${profile.organization}
    - Country of Interest: ${profile.country}
    - Primary Objective: ${profile.objective}
    - Primary Industry: ${profile.industry}
    - Company Size: ${profile.companySize || 'Not Provided'}
    - Indicative Budget (USD): ${profile.budget || 'Not Provided'}
    - Incentives Offered by Government: ${profile.incentives || 'Not Provided'}

    Return ONLY the JSON object, without any surrounding text or markdown.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-04-17',
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^\`\`\`(\w*)?\s*\n?(.*?)\n?\s*\`\`\`$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
          jsonStr = match[2].trim();
        }

        const aiResult = JSON.parse(jsonStr);

        return Object.assign({}, profile, {
            executiveSummary: aiResult.executiveSummary,
            urpIndex: aiResult.urpIndex,
            riskScore: aiResult.riskScore,
            partnerArchetypes: aiResult.partnerArchetypes,
            recommendedTier: aiResult.recommendedTier,
            keyOpportunities: aiResult.keyOpportunities,
            keyRisks: aiResult.keyRisks,
        });
    } catch (error) {
        console.error("Gemini API call failed:", error);
        return getFallbackAnalysis(profile); // Fallback to mock data on error
    }
}

function getFallbackAnalysis(profile) {
    console.warn("Using fallback mock data due to API error or missing API key.");
    return {
        ...profile,
        executiveSummary: `NSIL™ Analysis: For your objective of "${profile.objective}", our AI indicates ${profile.country} demonstrates a strong URP Index of 8.2. Key assets include a growing skilled workforce and strategic port access. This potential is balanced by a moderate risk profile of 5.7, primarily driven by regulatory uncertainty, requiring targeted due diligence.`,
        urpIndex: 8.2,
        riskScore: 5.7,
        partnerArchetypes: ["Local logistics provider", "Real estate developer", "Construction firm"],
        recommendedTier: "Tier 2: Strategic Partnership Facilitator",
        keyOpportunities: ["Untapped domestic market", "Proximity to key ASEAN trade routes", "Supportive local government"],
        keyRisks: ["Regulatory shifts", "Infrastructure bottlenecks in rural areas", "Skilled labor competition"],
    };
}

function renderContent(templateName, ...args) {
    const contentArea = document.getElementById('content-area');
    if (!contentArea) return;
    const templateFn = templates[templateName];
    contentArea.innerHTML = typeof templateFn === 'function' ? templateFn(...args) : templateFn;
    addEventListenersForView(templateName);
}

function showView(viewId, viewName) {
    activeView = viewId;
    const viewTitle = document.getElementById('view-title');
    if (viewTitle) viewTitle.textContent = viewName;
    renderSidebar();
    
    if (viewId === 'generator') {
        renderContent('welcome');
    } else if (viewId === 'map') {
        renderContent('map');
    } else {
         renderContent('welcome');
    }
}

function renderSidebar() {
    const navItems = [
        { id: 'generator', name: 'AI Report Builder', icon: ICONS.builder },
        { id: 'map', name: 'Global Opportunity Map', icon: ICONS.map },
    ];
    const nav = document.getElementById('sidebar-nav');
    if (!nav) return;
    nav.innerHTML = navItems.map(item => `
        <button id="btn-${item.id}" class="sidebar-btn ${item.id === activeView ? 'active' : ''}">
            ${item.icon}
            ${item.name}
        </button>
    `).join('');
    navItems.forEach(item => {
        document.getElementById(`btn-${item.id}`)?.addEventListener('click', () => showView(item.id, item.name));
    });
}

function startBuilder(type) {
    userProfile.userType = type;
    renderContent('builderForm', type);
}

async function handleGenerate() {
    const orgInput = document.getElementById('organization');
    const objSelect = document.getElementById('objective');
    const countrySelect = document.getElementById('country');
    const industrySelect = document.getElementById('industry');
    
    if (!orgInput.value || !objSelect.value || !countrySelect.value || !industrySelect.value) {
        alert('Please complete all required fields.');
        return;
    }
    
    userProfile.organization = orgInput.value;
    userProfile.objective = objSelect.value;
    userProfile.country = countrySelect.value;
    userProfile.industry = industrySelect.value;

    const companySizeEl = document.getElementById('companySize');
    userProfile.companySize = companySizeEl ? companySizeEl.value : null;
    
    const budgetEl = document.getElementById('budget');
    userProfile.budget = budgetEl && budgetEl.value ? parseFloat(budgetEl.value) : null;
    
    const incentivesEl = document.getElementById('incentives');
    userProfile.incentives = incentivesEl ? incentivesEl.value : null;
    
    renderContent('loading');
    generatedReport = await runNexusAiAnalysis(userProfile);
    renderContent('result');
    populateResults();
}

function populateResults() {
    const resultOrgName = document.getElementById('result-org-name');
    if(resultOrgName) resultOrgName.textContent = generatedReport.organization || '';

    const metricUrp = document.getElementById('metric-urp');
    if(metricUrp) metricUrp.textContent = generatedReport.urpIndex?.toFixed(1) ?? 'N/A';

    const metricRisk = document.getElementById('metric-risk');
    if(metricRisk) metricRisk.textContent = generatedReport.riskScore?.toFixed(1) ?? 'N/A';

    const metricTier = document.getElementById('metric-tier');
    if(metricTier) metricTier.textContent = generatedReport.recommendedTier ?? 'N/A';
    
    const summaryContainer = document.getElementById('report-summary-container');
    if (summaryContainer) {
        summaryContainer.innerHTML = `<h3 class="font-semibold text-xl mb-3 text-slate-900">AI-Generated Executive Summary</h3><p class="text-base leading-relaxed">${generatedReport.executiveSummary || 'No summary available.'}</p>`;
    }
}

function downloadPdf() {
    const { jsPDF, autoTable } = window.jspdf;
    const doc = new jsPDF();
    const { organization = 'report', executiveSummary, urpIndex, riskScore, recommendedTier, keyOpportunities, keyRisks } = generatedReport;

    // Header
    doc.setFont("helvetica", "bold");
    doc.setFontSize(24);
    doc.setTextColor(40);
    doc.text("BWGA Nexus 7.0", 105, 22, { align: 'center' });
    doc.setFontSize(14);
    doc.setTextColor(100);
    doc.text("AI-Human Intelligence Brief", 105, 30, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`FOR: ${organization.toUpperCase()}`, 105, 36, { align: 'center' });
    
    doc.setDrawColor(224, 224, 224); // Light gray
    doc.line(15, 45, 195, 45);

    // Section 1: Executive Summary
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(40);
    doc.text("1. AI-Generated Executive Summary", 15, 55);
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(60);
    const summaryLines = doc.splitTextToSize(executiveSummary || 'No summary available.', 180);
    doc.text(summaryLines, 15, 63);

    const summaryHeight = doc.getTextDimensions(summaryLines).h;
    let currentY = 63 + summaryHeight + 15;

    // Section 2: Core Metrics
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(40);
    doc.text("2. Core AI Metrics & Recommendations", 15, currentY);
    currentY += 8;

    doc.autoTable({
        startY: currentY,
        head: [['Metric', 'Score/Value', 'Description']],
        body: [
            ['URP Index™', urpIndex?.toFixed(1) ?? 'N/A', 'Measures untapped regional potential.'],
            ['AGER-AI™ Risk Score', riskScore?.toFixed(1) ?? 'N/A', 'Assesses governance and stability.'],
            ['Recommended Tier', recommendedTier ?? 'N/A', 'Suggested engagement level for this opportunity.'],
        ],
        theme: 'grid',
        headStyles: { fillColor: [79, 70, 229] }, // Indigo
    });
    
    let finalY = doc.lastAutoTable.finalY;
    if (finalY === undefined) {
      finalY = currentY + 40; // Fallback position
    }
    currentY = finalY + 15;

    // Section 3: Key Factors
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(40);
    doc.text("3. Key Factors Analysis", 15, currentY);
    currentY += 8;

    doc.autoTable({
        startY: currentY,
        head: [['Key Opportunities', 'Key Risks']],
        body: [
            [(keyOpportunities || []).map(item => `• ${item}`).join('\n'), (keyRisks || []).map(item => `• ${item}`).join('\n')],
        ],
        theme: 'grid',
        headStyles: { fillColor: [30, 41, 59] }, // slate-800
        styles: { cellPadding: 4, valign: 'top' },
    });

    // Footer on each page
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width / 2, 287, { align: 'center' });
        doc.text(`CONFIDENTIAL - BWGA Global Advisory © ${new Date().getFullYear()}`, 15, 287);
    }

    doc.save(`BWGA_Aegis_Brief_${organization.replace(/\s/g, '_')}.pdf`);
}

function addEventListenersForView(viewName) {
    if (viewName === 'welcome') {
        document.getElementById('start-business-btn')?.addEventListener('click', () => startBuilder('Business'));
        document.getElementById('start-government-btn')?.addEventListener('click', () => startBuilder('Government'));
    } else if (viewName === 'builderForm') {
        document.getElementById('back-to-welcome-btn')?.addEventListener('click', () => showView('generator', 'AI Report Builder'));
        document.getElementById('generate-brief-btn')?.addEventListener('click', handleGenerate);
    } else if (viewName === 'result') {
        document.getElementById('download-pdf-btn')?.addEventListener('click', downloadPdf);
        document.getElementById('start-new-report-btn')?.addEventListener('click', () => showView('generator', 'AI Report Builder'));
    }
}

// --- Initialization ---
function initializeDashboard() {
    const appContainer = document.getElementById('app-container');
    if (!appContainer) return;
    appContainer.innerHTML = templates.shell;
    renderSidebar();
    showView('generator', 'AI Report Builder');
}

document.addEventListener('DOMContentLoaded', () => {
    // This check is crucial for plugins in non-module environments.
    if (window.jspdf && window.jspdf.jsPDF && window.jspdf.autoTable) {
        window.jspdf.jsPDF.API.autoTable = window.jspdf.autoTable;
    }
    initializeDashboard();
});
